-- Status:18:1261:MP_0:sessions:php:1.24.4::5.5.29:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|assistant|8|16384||InnoDB
-- TABLE|backup|201|65536||InnoDB
-- TABLE|bakdrive|9|32768||InnoDB
-- TABLE|chanFault|7|65536||InnoDB
-- TABLE|channels|122|49152||InnoDB
-- TABLE|client|99|16384||InnoDB
-- TABLE|composer|79|16384||InnoDB
-- TABLE|engineer|14|32768||InnoDB
-- TABLE|fixer|9|32768||InnoDB
-- TABLE|micFault|8|65536||InnoDB
-- TABLE|micLog|76|65536||InnoDB
-- TABLE|microphones|244|81920||InnoDB
-- TABLE|project|125|16384||InnoDB
-- TABLE|recdrive|9|32768||InnoDB
-- TABLE|session|204|180224||InnoDB
-- TABLE|sessmics|33|16384||InnoDB
-- TABLE|studio|3|16384||InnoDB
-- TABLE|users|11|49152||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2013-04-08 15:12

--
-- Create Table `assistant`
--

DROP TABLE IF EXISTS `assistant`;
CREATE TABLE `assistant` (
  `astID` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `astName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`astID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `assistant`
--

/*!40000 ALTER TABLE `assistant` DISABLE KEYS */;
INSERT INTO `assistant` (`astID`,`astName`) VALUES ('1',NULL);
INSERT INTO `assistant` (`astID`,`astName`) VALUES ('2','Jeremy Murphy');
INSERT INTO `assistant` (`astID`,`astName`) VALUES ('3','Chris Parker');
INSERT INTO `assistant` (`astID`,`astName`) VALUES ('4','Joshua Thomas');
INSERT INTO `assistant` (`astID`,`astName`) VALUES ('5','Tom Halstead');
INSERT INTO `assistant` (`astID`,`astName`) VALUES ('6','Stuart Binns');
INSERT INTO `assistant` (`astID`,`astName`) VALUES ('7','Alex Watson');
INSERT INTO `assistant` (`astID`,`astName`) VALUES ('8','Steve Price');
/*!40000 ALTER TABLE `assistant` ENABLE KEYS */;


--
-- Create Table `backup`
--

DROP TABLE IF EXISTS `backup`;
CREATE TABLE `backup` (
  `bakID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bakName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bakLoc` tinyint(3) unsigned DEFAULT NULL,
  `bakDate` datetime DEFAULT NULL,
  `fullCopy` tinyint(1) DEFAULT NULL,
  `bakCupboard` tinyint(1) DEFAULT NULL,
  `bakKeep` tinyint(1) DEFAULT NULL,
  `bakNotes` blob,
  `bakMov` tinyint(3) unsigned DEFAULT NULL,
  `bakLastDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bakDeleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`bakID`),
  KEY `bakMov` (`bakMov`),
  CONSTRAINT `backup_ibfk_1` FOREIGN KEY (`bakMov`) REFERENCES `studio` (`stdID`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `backup`
--

/*!40000 ALTER TABLE `backup` DISABLE KEYS */;
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('1','130205 MBCP3 Peter Salem_Call The Midwife_S02Ep07','7','2013-02-05 16:19:17','1','0','0','Peter has taken full copies',NULL,'2013-02-27 17:00:12','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('2','130124 GTJT3 Silver Screen Choir','7','2013-02-05 16:22:15','1','0','0','',NULL,'2013-02-27 17:29:28','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('3','130119 GTCP3 Marple ACM Pro Tools Sessions','7','2013-02-05 16:25:02','1','0','0','Dominik has taken a full copy',NULL,'2013-02-27 16:58:13','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('4','130118 MBJT3 Disney LionKing','7','2013-02-05 16:27:19','1','0','0','',NULL,'2013-02-27 17:29:42','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('5','130118 MBCP3 Peter Salem_Call The Midwife_S02Ep06','7','2013-02-05 16:29:00','1','0','0','Full copy taken by Peter',NULL,'2013-02-27 16:57:49','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('6','121127 MBCP3 Si Hale Darius Stgs','7','2013-02-05 16:35:34','1','0','0','Client taken full copy\r\n\r\nConfirmed with Chris P',NULL,'2013-03-06 14:54:18','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('7','121126 SPJM1 Andrew Skeet Zarina Orch+Vox','1','2013-02-05 16:43:36','0','0','0','','3','2013-02-07 15:25:43','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('8','121126 SPJM1 Andrew Skeet Zarina Orch+Vox','7','2013-02-05 16:44:03','1','0','0','Full Copy in 2 after Mixing','2','2013-02-27 17:04:57','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('9','120703 MBCP3 Spanish DeWolfe_2 Vocalists','7','2013-02-05 17:05:23','0','0','0','',NULL,'2013-02-27 17:09:50','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('10','121022 GTJM3 ROTB','7','2013-02-05 17:06:56','1','0','0','Full copy taken\r\n\r\nConfirmed with Gary',NULL,'2013-03-06 14:56:09','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('11','111101 MBCP3 Dom James De Wolfe BRAZIL','7','2013-02-05 17:10:08','0','1','0','Copy on DeWolfe drive',NULL,'2013-02-27 16:20:29','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('12','120118 MB DW Hair of the Dog','7','2013-02-05 17:10:32','0','0','0','',NULL,'2013-02-27 17:09:48','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('13','120125 MB DW Caribbean Package Tour','7','2013-02-05 17:10:42','0','0','0','',NULL,'2013-02-27 17:09:55','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('14','121014 SPJM3 Boosey and Hawkes RACH','7','2013-02-05 17:12:04','1','0','0','1 Copy Taken',NULL,'2013-02-27 16:44:14','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('15','121026 MBCP3 Finchly Childrens Music','7','2013-02-05 17:12:17','1','0','1','Copy taken\r\n\r\nOngoing Project - Next 12 Months',NULL,'2013-02-27 16:45:42','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('16','121101 SMJMJT3 North Pole','7','2013-02-05 17:12:26','1','0','0','Film is out',NULL,'2013-02-27 16:48:12','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('17','121104 SRJT3 Morrisons','7','2013-02-05 17:12:36','1','0','0','',NULL,'2013-02-27 17:30:26','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('18','121118 GTJT3 Arsenal Choir','7','2013-02-05 17:12:46','1','0','0','',NULL,'2013-02-27 17:30:15','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('19','121119 GTJM3 ROB LANE The Making Of A Lady EP1','7','2013-02-05 17:12:56','1','0','0','2 Copies taken on Hard Drive',NULL,'2013-02-27 16:52:52','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('20','121122 SPJM3 DWiseman Pno + Vocal Feather Boy','7','2013-02-05 17:13:04','0','1','0','Copy on Debbies Drive 2',NULL,'2013-02-27 17:10:40','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('21','121126 GTCP3 DAN JONES Fear ','7','2013-02-05 17:13:12','1','0','0','Dan Jones has full copies of Sessions',NULL,'2013-03-06 14:57:00','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('22','DOTE','8','2013-02-06 11:28:07','0','0','1','Check with Steve / Jez',NULL,'2013-02-27 15:59:40','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('23','120118 GTJT3 EDMUNDO ROSS 1995','8','2013-02-06 11:28:19','0','1','1','Transferred from Radar to Pro Tools\r\n\r\nGary to Mix\r\n\r\nASK GARY',NULL,'2013-02-27 17:33:57','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('24','120327 GTJT2 Spanish DeWolfe','8','2013-02-06 11:28:37','0','1','0','Copy on Dewolfe drive',NULL,'2013-02-27 16:00:44','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('25','DOTE','8','2013-02-06 11:28:48','0','0','0','',NULL,'2013-02-07 15:25:43',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('26','120920 GTCP3 LCO SATV','8','2013-02-06 11:29:03','1','0','0','Copy taken by client\r\n\r\nConfirmed with Chris P',NULL,'2013-03-06 14:49:48','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('27','DOTE','8','2013-02-06 11:29:11','0','0','0','',NULL,'2013-02-07 15:25:43',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('28','121008 GTTH3 ALAIN CLARK','8','2013-02-06 11:30:01','1','0','0','Client taken copy\r\n\r\nConfirmed with Gary',NULL,'2013-03-06 14:58:57','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('29','121017 SBJT3 Fairytale For Angel','8','2013-02-06 11:30:11','0','0','0','',NULL,'2013-02-27 17:31:16','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('30','121029 GTCP3 Ben Bartlett FALCON','8','2013-02-06 11:30:23','1','0','0','Client taken full copy\r\n\r\nConfirmed with Chris P',NULL,'2013-03-06 14:52:08','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('31','121104 SRJT3 Morrisons','8','2013-02-06 11:30:38','1','0','0','Client taken full copy\r\n\r\nConfirmed with Joshua',NULL,'2013-03-06 14:55:29','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('32','121112 GTCP3 Martell AD Dunaigre','8','2013-02-06 11:31:01','1','0','0','Client taken full copy\r\n\r\nconfirmed with Chris P',NULL,'2013-03-06 14:52:50','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('33','121112 CDJM3 R Portman STILL LIFE Film','8','2013-02-06 11:31:10','1','0','0','Moved to 2','2','2013-02-27 17:04:42','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('34','121130 GTJT3 One More Music Plusnet','8','2013-02-06 11:31:21','1','0','0','Files taken Keep until January',NULL,'2013-02-27 16:13:03','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('35','121217 SPJM3 George Fenton KL The Spirit of 45','8','2013-02-06 11:31:32','0','0','0','',NULL,'2013-02-07 15:25:43',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('36','130102 MBJT3 One More Music','8','2013-02-06 11:31:43','0','0','0','',NULL,'2013-02-07 15:25:43',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('37','130108 SPJM3 Frazer T Smith STGS','8','2013-02-06 11:31:53','1','0','0','Full backup taken away',NULL,'2013-02-27 16:16:21','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('38','130115 SPJM3 Karl Jenkins Colores','8','2013-02-06 11:32:03','1','0','1','All files taken\r\n\r\nBUT\r\n\r\nOD\'s being done in March\r\n\r\nThis folder is within the latest Karl Jenkins folder',NULL,'2013-03-06 12:05:09','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('39','DeWolfe Tape Transfers','9','2013-02-06 11:58:59','0','0','1','Ask Gary / Warren',NULL,'2013-02-27 15:57:52','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('40','110318 SPJM3 Eaton Music A Nikitin','9','2013-02-06 11:59:12','1','0','0','',NULL,'2013-02-27 15:45:14','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('41','Gfenton Mrs Henderson The Musical','9','2013-02-06 11:59:21','0','0','1','Check with Steve / Jez look on George drive',NULL,'2013-02-27 15:57:28','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('42','120613 MBJT1 DW Troy Banarzi Folk','9','2013-02-06 11:59:32','0','1','0','Copy on Dewolfe drive 2',NULL,'2013-02-27 15:46:50','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('43','120620 GTJT3 RPO Rock','9','2013-02-06 11:59:43','1','1','1','Ask Gary','2','2013-02-27 17:32:05','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('44','120917 BMJM3 Without You','9','2013-02-06 11:59:52','1','0','0','2 Copies taken',NULL,'2013-02-27 15:49:11','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('45','121015 MBCP3 Tony Carreira','9','2013-02-06 12:00:02','1','0','0','2 copies taken',NULL,'2013-02-27 15:50:28','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('46','121018 SPJM3 Hothouse PEnglishby SOTL Pre Recs','9','2013-02-06 12:00:10','1','0','0','2 copies taken\r\n\r\n1 with Paul Englishby\r\n\r\n1 with HotHouse',NULL,'2013-02-27 15:51:11','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('47','121025 SPJM3 Choir Wish World','9','2013-02-06 12:00:18','1','0','0','1 copy taken on Hard Drive',NULL,'2013-02-27 15:51:56','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('48','121108 SPJM George Fenton MAGF Film','9','2013-02-06 12:00:26','1','0','0','Sam took a copy on George Fenton drive\r\n\r\nMixed in 2, more recent backup there.','2','2013-02-27 15:53:09','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('49','121207 GTCP3 MORE RPO ROCK','9','2013-02-06 12:00:35','1','1','0','Copies on Gary\'s drive and on RPO drive',NULL,'2013-02-27 15:54:18','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('50','121210 GTCP3 RPO John Barry and Others','9','2013-02-06 12:00:54','1','0','0','James Fitzpatrick has a copy on his drive',NULL,'2013-02-27 15:54:50','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('51','121211 GTCP3  EMIRATES Hello Tomorrow','9','2013-02-06 12:01:09','1','0','0','James Fitzpatrick has a copy\r\nChristopher Tim has a copy\r\n\r\nAlso uploaded via FTP',NULL,'2013-02-27 15:55:45','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('52','130105 SRJTCP3 JOBS John Debney','9','2013-02-06 12:01:19','1','0','0','',NULL,'2013-02-27 17:31:30','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('53','130204 JM R.PORTMAN-H.ZIMMER 10x10 Girl Rising 5.1 MIx','1','2013-02-06 17:08:32','1','0','0','Yann Taken Full Copy',NULL,'2013-02-07 15:25:43','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('54','130128 GTJT1 Lutoslawski Game Podcast','1','2013-02-06 17:08:45','1','0','0','All files taken',NULL,'2013-02-27 12:53:13','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('55','130123 MBCP1 David Arnold_Baaba Maal','1','2013-02-06 17:08:57','1','0','0','Full copy taken',NULL,'2013-02-27 12:52:51','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('56','130117 SPJM1 D Wiseman WPC 56 Ep1 + Ep2','1','2013-02-06 17:09:11','0','0','0','',NULL,'2013-02-07 15:25:43',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('57','130110 SPJT1 SCD TOUR One More Music','1','2013-02-06 17:09:29','1','0','0','2 Copies taken',NULL,'2013-02-27 12:52:08','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('58','130108 SPJM1 Peter Salem_Call The Midwife_S02Ep05','1','2013-02-06 17:09:41','1','0','0','1 Copy taken',NULL,'2013-02-27 12:51:35','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('59','130103 SPJM1 Boosey and Hawkes Jazz Library','1','2013-02-06 17:09:50','0','0','0','',NULL,'2013-02-07 15:25:43',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('60','121217 AICP1 Nyman Battleship Potemkin','1','2013-02-06 17:10:02','1','1','0','Austin has 2 copies\r\n\r\nproducer has 1 copy\r\n',NULL,'2013-03-19 12:24:22','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('61','121216 MBJT1 Boosey and Hawkes','1','2013-02-06 17:10:13','1','0','0','All copies taken',NULL,'2013-03-19 12:24:38','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('62','121213 SPJM1 Warner Chappell Steve Carter Library','1','2013-02-06 17:10:23','1','0','0','1 Copy taken',NULL,'2013-03-19 12:25:03','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('63','121211 SPJM1 Peter Salem_Call The Midwife_S02Ep04','1','2013-02-06 17:10:34','1','0','0','1 copy taken',NULL,'2013-03-19 12:25:25','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('64','121210 SPJM1 IR Laura Rossi Library','1','2013-02-06 17:10:43','1','0','0','1 Copy of all taken',NULL,'2013-03-19 12:25:59','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('65','112298 SPJM G Fenton KL FILM ANGELS SHARE','1','2013-02-06 17:11:04','0','0','1','See Jez / Steve',NULL,'2013-02-27 12:44:40','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('66','121207 MBJM1 Clod Ensemble Female Choir','1','2013-02-06 17:11:18','1','0','0','1 Copy of all taken',NULL,'2013-03-19 12:23:41','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('67','121130 MBCP1 SATV sessions Cliff Masterson ','1','2013-02-06 17:12:05','1','0','0','Copy taken',NULL,'2013-03-19 12:25:43','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('68','121106 MBJM Horn Prods Renato Zero',NULL,'2013-02-06 17:12:15','0','0','0','',NULL,'2013-02-07 15:25:43',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('69','121029 MBJT1 The last Session Jay Prod','1','2013-02-06 17:12:26','1','1','0','Copy on Johns Drive',NULL,'2013-02-27 15:14:01','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('70','121026 GTJT1 Privates on Parade','1','2013-02-06 17:12:36','1','1','0','Copy on Johns drive',NULL,'2013-02-27 12:40:38','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('71','121020 SPCP1 Peter Salem_Call The Midwife_S02Ep01','1','2013-02-06 17:12:47','1','0','0','Copy taken',NULL,'2013-02-27 15:11:39','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('72','121016 JMJT1 Chris Egan','1','2013-02-06 17:12:59','1','0','0','1 Copy taken',NULL,'2013-02-27 12:42:15','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('73','121008 SPCP1 Peter Salem_Call The Midwife_S02Ep00','1','2013-02-06 17:13:09','1','0','0','Peter has copies on his HD',NULL,'2013-02-27 12:31:42','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('74','120922 PGJM1 Mr Selfridge 3+4','1','2013-02-06 17:13:21','1','0','0','2 Copies taken',NULL,'2013-02-27 12:30:36','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('75','120906 - SPCP2 Debbie Wiseman_Father Brown EP1&2','1','2013-02-06 17:13:35','0','1','0','Copy on Debbie drive 2',NULL,'2013-03-19 12:40:48','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('76','120905 NASB1 Homefront','1','2013-02-06 17:13:46','0','0','0','',NULL,'2013-02-27 12:29:19','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('77','120724 GT1 DW PIANO','1','2013-02-06 17:13:56','0','1','0','Copy on Dewolfe Drives',NULL,'2013-03-19 12:22:58','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('78','120123 SPJT1 George Fenton MrsHenderson','1','2013-02-06 17:14:09','0','0','1','Ask Steve to check with George',NULL,'2013-02-27 12:26:43','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('79','Emmanuelle Theme','1','2013-02-06 17:14:20','0','0','1','See Gary',NULL,'2013-02-27 12:26:27','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('80','111206 SPJM1 BBC Westminster G Fenton Big Band','1','2013-02-06 17:14:31','0','0','1','Ask Steve to check with George',NULL,'2013-02-27 12:26:12','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('81','La Premiere Fois PLEASE SEE STEVE!','1','2013-02-06 17:14:40','0','0','1','Please Ask Steve',NULL,'2013-02-27 12:25:05','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('82','130131 SPJM1 MT Cher Strings','2','2013-02-07 11:26:25','1','0','0','1 Copy taken',NULL,'2013-02-27 12:22:49','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('83','121121 SPJM1 Peter Salem_Call The Midwife_S02Ep02','2','2013-02-07 11:26:37','1','0','0','2 Copies taken',NULL,'2013-02-27 12:21:42','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('84','121119 MBCP1 Basho Music','2','2013-02-07 11:26:50','1','0','0','Mat has a copy',NULL,'2013-02-27 15:08:42','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('85','121102 SPJM2 Debbie Wiseman FATHER BROWN EP8 EP9','2','2013-02-07 11:27:04','1','1','0','Copy on Debbie Wiseman drive 2',NULL,'2013-03-19 12:40:51','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('86','121103 SPJM1 Viva Forever - Tracks for vocals Session 1','2','2013-02-07 11:27:14','1','0','0','1 Copy of files taken',NULL,'2013-02-27 12:20:03','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('87','121019 MBCP1 - Alexandra Burke - LALD','2','2013-02-07 11:27:26','1','0','0','Copy Taken',NULL,'2013-02-27 15:10:50','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('88','121017 SPCP1 Steve Wilson - The Raven that Refused to Sing','2','2013-02-07 11:27:36','1','0','0','Steve Wilson has full copies of the session',NULL,'2013-02-27 12:18:04','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('89','Wizard of Oz ANGEL HARP','2','2013-02-07 11:27:50','1','0','0','All files taken.',NULL,'2013-02-27 12:16:53','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('90','121011 SPJM Debbie Wiseman_Father Brown EP5&6','2','2013-02-07 11:28:01','0','1','0','Copy on Debbie drive 2',NULL,'2013-03-19 12:40:52','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('91','121002 NAJT1 Admiral VOs SPEKULATION','2','2013-02-07 11:28:09','1','0','0','1 Copy sent over WeTransfer',NULL,'2013-02-27 12:16:00','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('92','120926 MBJM1 SONY CM Little Mix','2','2013-02-07 11:28:18','1','0','0','Full copy taken',NULL,'2013-02-27 15:13:03','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('93','120924 MBJM Debbie Wiseman_Father Brown EP3&4','2','2013-02-07 11:28:28','0','1','0','Copy on Debbie drive 2',NULL,'2013-03-19 12:40:53','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('94','120919 MBJT1 BERENICE DONMAR','2','2013-02-07 11:28:39','1','0','0','2 copies taken.\r\n\r\nKeep 1 Month.',NULL,'2013-02-27 12:14:19','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('95','120917 GTJT1 Wise Buddah R1 Idents','2','2013-02-07 11:33:17','1','0','0','2 Copies taken\r\n\r\nKeep 1 Month',NULL,'2013-02-27 12:10:28','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('96','120911 MBJM1 STEPS Steve Lipson','2','2013-02-07 11:33:27','1','0','0','One copy taken by Steve',NULL,'2013-02-27 12:08:03','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('97','120910 MBJM Hot House One Chance','2','2013-02-07 11:33:36','1','0','1','Copy taken, Returning again, keep for completion',NULL,'2013-02-27 12:09:28','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('98','120908 MBJT1 Rob Lane The Spies of Warsaw','2','2013-02-07 11:33:46','1','0','0','All files taken by Rob',NULL,'2013-02-27 12:07:18','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('99','111021 George Fenton Callaborators','2','2013-02-07 11:33:58','0','0','1','Check with Steve/Jez\r\n\r\nSam to check Georges drive.',NULL,'2013-03-06 11:44:09','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('100','111017 GTJT1 Lesley Bricusse','2','2013-02-07 11:34:06','0','0','0','',NULL,'2013-02-27 12:11:35','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('101','110718 SPJM1 Nick Ross Big Band MASTER','2','2013-02-07 11:34:14','0','1','0','No Copies Taken\r\n\r\nCopy on Nick\'s Drive',NULL,'2013-03-04 13:01:26','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('102','130121 SPJM1 Big Band Reuben Fowler','3','2013-02-07 12:19:12','0','0','1','Mixing to come - Studio 2','2','2013-02-27 12:02:15','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('103','130117 MBJT1 Warner','3','2013-02-07 12:19:31','1','0','0','1 Copy taken',NULL,'2013-02-27 12:38:57','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('104','130116 GTCP1 Yellow Boat_New York Bakery','3','2013-02-07 12:19:41','0','0','0','Client has full copies on their drive.',NULL,'2013-02-27 12:00:51','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('105','130115 GTCP1 Ian Roberton LIBRARY STGS','3','2013-02-07 12:19:56','1','0','0','Ian has taken a full copy',NULL,'2013-02-27 12:00:16','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('106','121205 MBJM1 Viva Forever - Tracks for vocals Session 2','3','2013-02-07 12:20:07','1','0','0','1 copy of everything taken',NULL,'2013-03-19 12:27:16','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('107','121204 GTJT2 Silver Screen Soundtracks','3','2013-02-07 12:20:19','1','0','0','All files taken',NULL,'2013-03-19 12:27:32','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('108','121126 SPJM1 Peter Salem_Call The Midwife_S02Ep03','3','2013-02-07 12:20:29','1','0','0','',NULL,'2013-03-19 12:27:02','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('109','121122 SPJM Debbie Wiseman_Father Brown EP7&10','3','2013-02-07 12:20:38','0','1','0','Backup On Debbie drive 2',NULL,'2013-03-19 12:40:55','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('110','121023 MBCP1 Salvation Army','3','2013-02-07 12:20:47','1','0','0','Copy taken',NULL,'2013-02-27 15:08:20','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('111','121005 SPCP1 Warner Classics Strings','3','2013-02-07 12:20:57','1','0','0','Copy taken',NULL,'2013-02-27 15:07:41','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('112','121004 SPJM1 One More Music ACER Megan','3','2013-02-07 12:21:05','1','0','0','1 Copy taken by Mark',NULL,'2013-02-27 11:51:44','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('113','AP STRINGS String Session A Munsey','3','2013-02-07 12:21:19','0','0','0','',NULL,'2013-02-27 11:49:04','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('114','EP 3 PRO TOOLS SESSIONS','3','2013-02-07 12:21:30','0','0','0','',NULL,'2013-03-19 12:26:45','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('115','120709 GTJM1 BS CM Il Divo','3','2013-02-07 12:21:42','0','0','0','',NULL,'2013-03-19 12:28:02','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('116','JAVIER BORDA SESSIONS','3','2013-02-07 12:22:00','0','0','0','',NULL,'2013-02-27 11:45:45','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('117','JAVIER BORDA SESSIONS','3','2013-02-07 12:22:17','0','0','0','',NULL,'2013-02-27 11:45:44','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('118','JAVIER BORDA SESSIONS','3','2013-02-07 12:22:25','0','0','0','',NULL,'2013-02-27 11:45:42','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('119','130115 and 121219 MBJT2 Jay Prod','4','2013-02-07 12:44:59','0','1','0','On John Yapp Drive',NULL,'2013-02-28 14:55:17','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('120','121219 MBJT2 Jay Prod','4','2013-02-07 12:45:37','0','1','0','On John Yapp Drive',NULL,'2013-02-28 14:57:24','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('121','121214 MBJT2 Finchley Choir','4','2013-02-07 12:45:48','0','0','1','Continuing for next 12 months',NULL,'2013-02-28 11:00:39','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('122','121210 MB2 John Yapp Shaun Yapp','4','2013-02-07 12:45:59','0','1','0','121210 MB2 John Yapp Shaun Yapp',NULL,'2013-02-28 14:55:49','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('123','121106 GTJT2 Silver screen','4','2013-02-07 12:46:14','1','0','0','Full sessions taken',NULL,'2013-02-28 11:04:17','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('124','121031 GTJT2 Miguel Moncloa & Naomi Scott','4','2013-02-07 12:46:25','1','0','0','Miguel has full copy\r\n\r\nConfirmed via email (Aimee) 070313',NULL,'2013-03-14 20:42:51','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('125','121010 GT2 KIRSCH','4','2013-02-07 12:47:09','0','1','1','Continuing\r\n\r\nSee Gary',NULL,'2013-02-28 10:57:14','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('126','121002 GT2 LOE S&S 2013','4','2013-02-07 12:47:18','1','0','0','Confirmed via Email (Aimee)\r\n\r\nsafe to delete (280213)',NULL,'2013-02-28 16:57:49','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('127','120814 MBCP2 Tenors Of Rock','4','2013-02-07 12:47:26','0','0','0','',NULL,'2013-02-07 15:25:43',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('128','120528 MBCP2 GF Mrs H Demos','4','2013-02-07 12:47:35','0','0','1','Check with Jez/Steve to check with George/Sam for Georges drive',NULL,'2013-02-28 10:51:23','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('129','110412 MBJT2 George Fenton Demo','4','2013-02-07 12:47:44','0','0','1','Check with Jez/Steve\r\n\r\nCheck with Sam/George for Georges Drive',NULL,'2013-02-28 10:50:33','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('130','121127 SPJM1 Big Band Callum Au','5','2013-02-07 12:58:54','0','0','0','',NULL,'2013-02-07 15:25:43',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('131','121112 CDJM3 R Portman STILL LIFE Film','5','2013-02-07 12:59:04','1','0','0','Rachel has a copy and a copy on the Still Life drive.',NULL,'2013-02-28 10:47:25','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('132','121108 SPJM George Fenton MAGF Film','5','2013-02-07 12:59:12','1','0','1','Copies taken\r\n\r\nKeep until June 2013',NULL,'2013-02-28 11:45:56','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('133','121022 MBJT2 Pascale','5','2013-02-07 12:59:22','1','0','0','',NULL,'2013-02-28 15:02:07','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('134','121003 GTCP3 Stimmung TV - UPMC2','5','2013-02-07 12:59:32','0','0','0','',NULL,'2013-02-28 11:01:10','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('135','120515 GTJT2 TOM LE CANCRE','5','2013-02-07 12:59:41','1','0','1','Keep until end of May 2013\r\n\r\nPossible re mix & Mastering',NULL,'2013-04-02 14:41:37','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('136','120213 MBJT2 Phantom Cameron Mackintosh','5','2013-02-07 12:59:49','1','0','0','USB stick sent by Dan from backup computer.\r\n\r\nAimee and sessions email confirmed',NULL,'2013-02-28 10:40:39','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('137','130201 GTJS2 Shed','6','2013-02-07 15:24:13','1','0','0','1 copy taken and 1 copy uploaded',NULL,'2013-02-28 10:38:24','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('138','121126 SPJM1 Andrew Skeet Zarina Orch+Vox','6','2013-02-07 15:24:22','1','0','0','Andrew has taken full copy on HD',NULL,'2013-02-28 10:37:24','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('139','121123 GTJT2 Negus Fancey','6','2013-02-07 15:24:31','1','0','0','Christmas Album\r\n\r\nJosh says they took full copy',NULL,'2013-02-28 11:43:07','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('140','121022 GTJM3 ROTB','6','2013-02-07 15:24:40','1','0','0','Full Sessions Taken',NULL,'2013-02-28 11:05:02','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('141','120914 NASB3 Jennifer Whyte Mozart Edition','6','2013-02-07 15:24:49','1','0','0','Drive sold to Mozart edition GB \r\n\r\n05/03/13\r\n\r\nDealt with by Aimee',NULL,'2013-03-06 14:45:19','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('142','120901 SPCP1 Tom Parker_New London Chorale','6','2013-02-07 15:25:01','1','0','0','Drive sold to Omroep 06/03/13\r\n\r\n\r\nDealt with by Aimee',NULL,'2013-03-06 14:42:37','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('143','120320 SPJM1 Emi Prods STRING ALBUM JCooper KEEP','6','2013-02-07 15:25:08','1','0','0','Email to sessions saying it could be deleted',NULL,'2013-02-28 10:28:44','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('144','120224 SPJM1 KPM DAVE HEWSON','6','2013-02-07 15:25:18','1','0','0','Copy sent to EMI 18/03/13\r\n\r\nCan be deleted confirmed via Email with Aimee',NULL,'2013-03-18 15:32:14','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('145','120215 NACP2 Scapegoat Mix DO NOT DELETE','6','2013-02-07 15:25:31','1','0','0','Chris says backup has been taken',NULL,'2013-02-28 11:35:09','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('146','100923 SPJM3 GF Frozen Planet EP5','6','2013-02-07 15:25:43','1','0','1','Check with Jez/Steve\r\n\r\nCheck its on Georges Drive',NULL,'2013-02-28 10:24:27','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('147','121031 MBCP1 Rob Lane Murder On The Home Front','3','2013-02-07 15:27:26','1','0','1','Big Band Pre-Records - Stem Mixes added 07.02.13\r\n\r\nKeep until 7th April',NULL,'2013-02-27 15:10:21','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('148','130205 SPJM1 D Wiseman WPC 56 Ep3 + Ep4','1','2013-02-07 16:29:45','0','1','0','On Debbie Backup Drive 2.',NULL,'2013-02-27 12:53:56','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('149','080213 GTCP1 Murder On The Home Front EP1_EP2 Rob Lane','2','2013-02-08 14:37:43','1','0','0','Rob has taken a full copy of the sessions on his HDD',NULL,'2013-02-27 12:23:03','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('150','DeWolfe Album Remaster for Jez (Actually Chris)','5','2013-02-11 17:08:30','0','0','0','',NULL,'2013-02-11 17:08:30',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('151','130212 MBCP1 Paul Potts One Chance','2','2013-02-12 21:15:11','1','0','0','David Walter Has Taken a Full Copy.\r\n\r\nHot House Have Also Taken a Full Copy.\r\n\r\nStripped out sessions were also transferred to Gedney.',NULL,'2013-02-12 21:15:11',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('152','130212 GTJT2 Levi Roots Vocal Recordings','5','2013-02-12 23:39:08','1','0','0','Day 1 of 3',NULL,'2013-02-28 11:37:59','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('153','130213 MBCP3 Speculation ADMIRAL','8','2013-02-13 21:38:11','0','0','1','Stems and Rough mixes have been transferred to Pietro Diana\r\n\r\npietro.diana@me.com\r\npietro.diana@admiralgroup.co.uk\r\n\r\nFULL SESSION COPY HAS NOT BEEN TAKEN!\r\n\r\nKEEP LONGER: Advert is not animated yet, may come back for tweaks.',NULL,'2013-02-13 21:39:21','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('154','130212 GTJT2 Levi Roots Vocal Recordings','5','2013-02-13 22:26:29','1','0','0','Day 3 of 3',NULL,'2013-02-14 23:16:44','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('155','130212 GTJT2 Levi Roots Vocal Recordings','5','2013-02-13 22:27:22','1','0','0','Day 2 of 3',NULL,'2013-02-28 11:38:05','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('156','130214 SPJM1 Warner Chappell Roberto','1','2013-02-14 11:36:53','1','0','0','Roberto= Producer\r\nRoberto Taken Copy Of Everything, Composers taken a copy of everything also. Keep 3 Months STANDARD',NULL,'2013-02-14 21:20:27','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('157','130206 Ryo Angel String Recording','7','2013-02-16 13:42:09','1','0','0','',NULL,'2013-02-16 21:30:14','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('158','130216 JMJT2 Finchley Childrens Choir','5','2013-02-16 14:59:50','1','0','1','Carrying On\r\nNOTES MADE IN COMMENTS FOR ON GOING WORK',NULL,'2013-02-28 10:49:16','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('159','130212 GTJT2 Levi Roots Vocal Recordings','5','2013-02-18 12:06:38','1','0','0','Extra Mix Session\r\n\r\nDay 4 of 3',NULL,'2013-02-28 11:38:20','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('160','130218 MBCP1 Peter Salem_Call The Midwife_S02Ep08','1','2013-02-18 12:56:58','1','0','0','Peter Has FULL copies of the sessions.',NULL,NULL,NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('161','130218 SPJM3 Chris Egan RPO Coldplay','8','2013-02-18 17:55:29','1','0','0','Tristan Taken 1 Full Copy Keep 3 months DRIVE 2 REC on 3_3 (extra audio)',NULL,'2013-02-18 17:57:45','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('162','130222 MBJT3 Adam Cork','7','2013-02-22 14:41:08','1','0','0','All 89s on strings',NULL,'2013-02-22 14:41:08','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('163','130225 SPCP1 D Wiseman WPC 56 Ep5','4','2013-02-22 16:43:26','0','0','0','Click Sessions put on Transfer 2, and taken to Studio 1 to continue with on monday 25/02/13.','1','2013-02-22 16:59:38','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('164','130225 SPCP1 D Wiseman WPC 56 Ep5','1','2013-02-25 09:39:04','1','1','0','Copy On Debbie\'s Backup Drive 2',NULL,'2013-02-25 09:39:04','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('165','130226 MBCP1 Jahmene Douglas Album STGS and CHOIR','1','2013-02-26 08:18:51','1','0','0','Matt Furmidge Has taken a full copy of the days work on his drive.',NULL,'2013-02-26 23:06:27','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('167','130301 SPJM1 Sony Prod Music David Arnold Brass + Perc','1','2013-03-01 17:41:41','1','0','0','Tom (composer) taken Full Copy KEEEP 3 MONTHS',NULL,'2013-03-01 17:41:41','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('168','130302 MBCP3 Finchly Childrens Music More Choir','7','2013-03-02 12:35:46','1','0','0','',NULL,'2013-03-02 17:03:53','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('169',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-02-25 15:31:41',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('170','130108 MBJT2 Pietro','5','2013-02-28 15:11:28','1','0','0','Anna took all files',NULL,'2013-02-28 15:11:28','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('171','130204 SPJM3 Karl Jenkins Colores Tpt + Piano','8','2013-03-04 18:43:00','1','0','0','Karl Taken FULL Backup, The Old Past sessions of colores are now ALL in this new folder',NULL,'2013-03-06 12:03:23','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('173','130306 MBJT1 Holland Park Opra_RBKC','1','2013-03-06 15:41:07','1','0','0','Will Todd Took All Files',NULL,'2013-03-06 15:41:07','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('174','130307 GTCP1 David Mitcham ICE AGE Ep1 and Opening','1','2013-03-07 21:49:40','1','0','0','David has a full copy of the orchestral AND choir sessions from today\r\n\r\nChoir Stuff NOT backed up in Studio 3',NULL,'2013-03-07 21:49:40','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('175','130307 MBJT2 LOE','4','2013-03-07 16:47:35','0','0','0','Hiroshi Kato - Will Take Drive on 7th March 2013',NULL,'2013-03-07 16:47:35','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('176','130307 GTCP3 David Mitcham ICE AGE Ep1 and Opening','7','2013-03-07 10:49:44','0','0','0','Client doesn\'t have a copy at this point. Moved upstairs to OD choir.','1','2013-03-07 18:19:30','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('178','130308 SPJM3 JAT Universal Childs Choir','7','2013-03-08 18:30:23','1','0','0','Ben (universal) Taken FULL COPY. KEEP 3 MONTHS',NULL,'2013-03-08 18:30:23','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('179','130309 MBCP1 Paul Potts One Chance_Young Paul','1','2013-03-09 18:54:08','1','0','0','Full Copy of the session has been transferred to Gedney Webb Via Dropbox.\r\n\r\ngedneyw@mac.com',NULL,'2013-03-09 18:54:08','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('180','130310 SPJM1 Chris Egan Music Above and Beyond','1','2013-03-10 17:05:40','1','0','0','Trist Taken FULL BACKUP. KEEP FOR 3 MONTHS',NULL,'2013-03-10 17:05:40','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('181','130212 GTJT2 Levi Roots Vocal Recordings','5','2013-03-11 10:57:20','0','0','1','ON GOING MORE VOCALS TO BE ADDED\r\n\r\nLevi will take away 2 copies of everything though.',NULL,'2013-03-12 11:19:20','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('182','N/A','7','2013-03-12 09:20:13','1','0','0','Pyramix session.\r\n\r\nNo backup with us. ',NULL,'2013-03-12 09:20:29','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('183','130311 MBCP1 Warner Chapel_Cinematic Portraits','1','2013-03-11 13:05:14','1','0','0','Roberto has a full copy of the sessions on his HDD.',NULL,'2013-03-11 13:05:14','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('184','130312 GTJM1 DeWolfe_Altman FUNK!','1','2013-03-12 17:52:47','0','1','0','No copies Taken Yet.  Will Be on THURSDAY. MIXING in ST 2 THUR\r\n\r\n\r\nRecord Sessions added to Dewolfe Drive 13/03/13 by Dan','2','2013-03-13 10:42:15','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('185','N/A','1','2013-03-14 20:00:51','1','0','0','Done on Pyramix, We did not have a copy',NULL,'2013-03-14 20:00:56','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('186','N/A','1','2013-03-14 20:01:22','1','0','0','Done on Pyramix. We did not take a safety.',NULL,'2013-03-14 20:01:26','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('188','130316 MBJT1 Charlie A T Choc Factory','1','2013-03-15 19:59:09','0','0','0','Day 2 of 2\r\nCHECK WITH \'PLAYFUL PROD\' WHEN DELETING. FILES NOT TAKEN!!!!',NULL,'2013-03-18 11:53:01','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('189','130314 MBCP3 Macasso Rice Krispies','7','2013-03-14 17:01:16','0','0','0','The EXPORTS folder and session notes have been Wet Transferred to Mike at Mcasso Music.\r\n\r\nThey Don\'t use PT so they didn\'t want the whole session.',NULL,'2013-03-14 20:40:09','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('190','130314 GTJM2 DeWolfe_Altman FUNK! MIX','4','2013-03-14 19:59:33','0','1','0','Backed up to the DeWolfe Drive.\r\n\r\nJohn has taken full mixes away ( CD )',NULL,'2013-03-15 17:50:02','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('191','130313 MBJT3 Soho Music MORE THAN','8','2013-03-13 16:36:28','1','0','0','Put all Files on their DROPBOX',NULL,'2013-03-13 16:36:28','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('192','130317 MBCP1 Cool Musoc Rob Lane Quirke Ep1','2','2013-03-17 09:56:48','1','0','0','Rob has a full copy of the sessions on his new backup drive.',NULL,'2013-03-17 13:42:58','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('193','130318 GTJT1 Dominik Scherrer MISS MARPLE','1','2013-03-18 14:20:57','1','0','0','Dominik Scherrer Took all Files',NULL,'2013-03-18 14:20:57','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('194','130318 AICP3 Nyman Battleship Potemkin PIANO','7','2013-03-18 17:53:09','1','1','0','Didn\'t Copy the session onto the Angel Backups, as Austin took a full copy away with him and the Piano/Mixing Session was synchronised with the band recording session already on Nyman BU3.',NULL,'2013-03-20 11:28:29','1');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('196','130320 MBCP1 Cool Music Rob Lane Quirke Ep1_2','2','2013-03-20 14:44:51','1','0','0','',NULL,'2013-03-20 14:44:51','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('197','130320 GTJT3 DeWolfe Childrens Choir','7','2013-03-20 17:10:59','0','1','0','ON DeWolfe Drive ! ! !',NULL,'2013-03-20 17:10:59','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('198',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-03-15 18:10:59',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('199',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-03-15 18:11:46',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('200','130120 MBJT1 Cool Music Charlie Mole','1','2013-03-19 12:11:12','0','0','0','',NULL,'2013-03-19 12:11:12','0');
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('201',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-03-20 12:01:26',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('203',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-03-26 10:55:32',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('204',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-03-26 10:56:08',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('205',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-03-28 11:27:36',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('206',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-03-28 11:29:01',NULL);
INSERT INTO `backup` (`bakID`,`bakName`,`bakLoc`,`bakDate`,`fullCopy`,`bakCupboard`,`bakKeep`,`bakNotes`,`bakMov`,`bakLastDate`,`bakDeleted`) VALUES ('207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-04-08 11:17:04',NULL);
/*!40000 ALTER TABLE `backup` ENABLE KEYS */;


--
-- Create Table `bakdrive`
--

DROP TABLE IF EXISTS `bakdrive`;
CREATE TABLE `bakdrive` (
  `bkdID` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `bkdName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stdID` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`bkdID`),
  KEY `stdID` (`stdID`),
  CONSTRAINT `bakdrive_ibfk_1` FOREIGN KEY (`stdID`) REFERENCES `studio` (`stdID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `bakdrive`
--

/*!40000 ALTER TABLE `bakdrive` DISABLE KEYS */;
INSERT INTO `bakdrive` (`bkdID`,`bkdName`,`stdID`) VALUES ('1','1_1','1');
INSERT INTO `bakdrive` (`bkdID`,`bkdName`,`stdID`) VALUES ('2','1_2','1');
INSERT INTO `bakdrive` (`bkdID`,`bkdName`,`stdID`) VALUES ('3','1_3','1');
INSERT INTO `bakdrive` (`bkdID`,`bkdName`,`stdID`) VALUES ('4','2_1','2');
INSERT INTO `bakdrive` (`bkdID`,`bkdName`,`stdID`) VALUES ('5','2_2','2');
INSERT INTO `bakdrive` (`bkdID`,`bkdName`,`stdID`) VALUES ('6','2_3','2');
INSERT INTO `bakdrive` (`bkdID`,`bkdName`,`stdID`) VALUES ('7','3_1','3');
INSERT INTO `bakdrive` (`bkdID`,`bkdName`,`stdID`) VALUES ('8','3_2','3');
INSERT INTO `bakdrive` (`bkdID`,`bkdName`,`stdID`) VALUES ('9','3_3','3');
/*!40000 ALTER TABLE `bakdrive` ENABLE KEYS */;


--
-- Create Table `chanFault`
--

DROP TABLE IF EXISTS `chanFault`;
CREATE TABLE `chanFault` (
  `faultID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `channelID` smallint(5) unsigned DEFAULT NULL,
  `channelPos` tinyint(4) DEFAULT NULL,
  `faultDesc` blob,
  `faultDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userID` int(11) DEFAULT NULL,
  `faultOutcome` blob,
  PRIMARY KEY (`faultID`),
  UNIQUE KEY `faultID_UNIQUE` (`faultID`),
  KEY `chanFault_ibfk_1_idx` (`channelID`),
  KEY `chanFault_ibfk_2_idx` (`userID`),
  CONSTRAINT `chanFault_ibfk_1` FOREIGN KEY (`channelID`) REFERENCES `channels` (`channelID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `chanFault_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `users` (`usrID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `chanFault`
--

/*!40000 ALTER TABLE `chanFault` DISABLE KEYS */;
INSERT INTO `chanFault` (`faultID`,`channelID`,`channelPos`,`faultDesc`,`faultDate`,`userID`,`faultOutcome`) VALUES ('2','348','51','Metering doesn\'t work. Routing etc is fine.','2013-03-11 16:27:09','1',NULL);
INSERT INTO `chanFault` (`faultID`,`channelID`,`channelPos`,`faultDesc`,`faultDate`,`userID`,`faultOutcome`) VALUES ('3','349','52','Mic amp works but doesn\'t route anywhere.','2013-03-11 16:27:51','1',NULL);
INSERT INTO `chanFault` (`faultID`,`channelID`,`channelPos`,`faultDesc`,`faultDate`,`userID`,`faultOutcome`) VALUES ('4','154','54','Monitor Input Not working properly. Very Low level. \r\nGroup Sends not working','2013-03-15 15:03:42','1','Seperated Faults ');
INSERT INTO `chanFault` (`faultID`,`channelID`,`channelPos`,`faultDesc`,`faultDate`,`userID`,`faultOutcome`) VALUES ('5','137','54','Group Sends not working.','2013-03-15 16:19:15','1','Cleared');
INSERT INTO `chanFault` (`faultID`,`channelID`,`channelPos`,`faultDesc`,`faultDate`,`userID`,`faultOutcome`) VALUES ('6','154','37','Monitor Input not working.','2013-03-18 15:16:06','1',NULL);
INSERT INTO `chanFault` (`faultID`,`channelID`,`channelPos`,`faultDesc`,`faultDate`,`userID`,`faultOutcome`) VALUES ('7','154','37','Group output not working.','2013-03-18 15:16:33','1',NULL);
INSERT INTO `chanFault` (`faultID`,`channelID`,`channelPos`,`faultDesc`,`faultDate`,`userID`,`faultOutcome`) VALUES ('8','136','36','No routing on multitrack left side','2013-03-19 12:47:04','4',NULL);
/*!40000 ALTER TABLE `chanFault` ENABLE KEYS */;


--
-- Create Table `channels`
--

DROP TABLE IF EXISTS `channels`;
CREATE TABLE `channels` (
  `channelID` smallint(5) unsigned NOT NULL,
  `currentPos` tinyint(4) NOT NULL,
  `stdID` tinyint(3) unsigned DEFAULT NULL,
  `lastMoved` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`channelID`),
  UNIQUE KEY `channelID_UNIQUE` (`channelID`),
  KEY `channels_ibfk_1_idx` (`stdID`),
  CONSTRAINT `channels_ibfk_1` FOREIGN KEY (`stdID`) REFERENCES `studio` (`stdID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `channels`
--

/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('100','0','1','2013-03-04 12:31:16');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('101','1','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('102','2','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('103','3','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('104','4','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('105','5','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('106','6','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('107','7','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('108','8','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('109','9','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('110','10','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('111','11','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('112','12','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('113','13','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('114','14','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('115','15','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('116','16','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('117','17','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('118','18','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('119','19','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('120','20','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('121','21','1','2013-03-04 12:15:41');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('122','22','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('123','23','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('124','24','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('125','25','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('126','26','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('127','27','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('128','28','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('129','29','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('130','30','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('131','31','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('132','32','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('133','33','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('134','34','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('135','35','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('136','36','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('137','38','1','2013-03-15 16:19:26');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('138','54','1','2013-03-15 16:19:26');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('139','39','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('140','40','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('141','41','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('142','42','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('143','43','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('144','44','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('145','45','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('146','46','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('147','47','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('148','48','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('149','49','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('150','50','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('151','51','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('152','52','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('153','53','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('154','37','1','2013-03-15 15:03:52');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('155','55','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('156','56','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('157','57','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('158','58','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('159','59','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('160','60','1','2013-03-04 12:15:42');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('300','0','1','2013-03-04 12:31:16');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('301','1','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('302','57','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('303','4','3','2013-03-21 23:03:02');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('304','3','3','2013-03-21 23:03:02');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('305','5','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('306','6','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('307','7','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('308','8','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('309','9','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('310','10','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('311','11','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('312','12','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('313','13','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('314','32','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('315','15','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('316','16','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('317','17','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('318','18','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('319','19','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('320','20','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('321','21','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('322','22','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('323','23','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('324','24','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('325','25','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('326','26','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('327','27','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('328','28','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('329','29','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('330','30','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('331','31','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('332','14','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('333','33','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('334','34','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('335','2','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('336','36','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('337','37','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('338','38','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('339','39','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('340','40','3','2013-03-04 12:30:39');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('341','41','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('342','42','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('343','43','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('344','44','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('345','45','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('346','50','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('347','47','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('348','51','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('349','52','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('350','46','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('351','48','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('352','49','3','2013-03-11 16:22:29');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('353','53','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('354','54','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('355','55','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('356','56','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('357','35','3','2013-03-11 16:22:30');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('358','58','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('359','59','3','2013-03-04 12:30:40');
INSERT INTO `channels` (`channelID`,`currentPos`,`stdID`,`lastMoved`) VALUES ('360','60','3','2013-03-04 12:30:40');
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;


--
-- Create Table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `cliID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cliName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`cliID`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `client`
--

/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('1',NULL);
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('2','Debbie Wiseman');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('3','Cool Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('4','Silva Screen Records');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('5','Angel Song');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('6','Crown Talent');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('7','Khurshidam Altynbay');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('8','BBC Drama');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('9','Pitch & Sync');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('10','DLKW Lowe');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('11','North Pole Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('12','Finchley Childrens Music Group');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('13','Orange Eyes');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('14','Boosey & Hawkes');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('15','DeWolfe Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('16','Karl Jenkins Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('17','Island Records');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('18','One More Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('19','Annotate Ltd');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('20','SNC TBWA Prod');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('21','Still Life Productions');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('22','AtotheC Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('23','SATV Publishing');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('24','Edmundo Ross');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('25','Ruby Film & Television');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('26','Fairytale');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('27','Eaton Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('28','RPO');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('29','PS Classics');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('30','Regi Concerto');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('31','Hot House Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('32','Albion Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('33','HBO Film & TV');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('34','Warner Chappell');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('35','Rachel Portman');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('36','Philharmonia Orchestra');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('37','Tomboy Films');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('38','Trousers Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('39','Michael Nyman');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('40','Clod Ensemble');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('41','Horn Productions');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('42','Jay Productions');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('43','MGC Ltd');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('44','Chris Egan');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('45','Audio Beatroot');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('46','BBC');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('47','La Premiere Fois');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('48','Elite Artiste Management');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('49','Steve Socci Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('50','Nine Films Ltd');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('51','Steps LLP');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('52','Wise Buddah');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('53','Donmar Warehouse');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('54','Sony Music Entertainment');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('55','Speckulation');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('56','Steven Wilson Productions');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('57','VF London Ltd');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('58','Basho Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('59','Metrophonic Productions');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('60','Really Useful Group');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('61','Tadlow Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('62','Endorf Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('63','Salvation Army');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('64','Yellow Boat Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('65','Dave Stapleton');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('66','Infinity Video Ltd');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('67','Javier Borda');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('68','Tenors of Tock');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('69','LOE Ltd');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('70','Miguel Moncloa');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('71','Praxis Films');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('72','Cameron Mackintosh');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('73','Stimmung TV');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('74','Callum Au');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('75','John Quinn');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('76','Scapegoat Film Company');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('77','KPM');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('78','EMI Production');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('79','Omroep MAX');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('80','Jennifer Whyte');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('81','Negus-Fancey Co');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('82','Shed Media');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('83','Levi Roots');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('84','Finchley Childrens MG');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('85','Stephanie Silverio');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('86','Soho Production Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('87','Deutsche Gramophon');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('88','RBKC Accountancy Control');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('89','Universal Publishing');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('90','Vivace Ltd');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('91','Floating Earth');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('92','Decca Records');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('93','Music Productions Ltd');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('94','Playful Productions');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('95','Mcasso Music Production');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('96','Soho Music');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('97','Mandarin Cinema');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('98','PEZ Management');
INSERT INTO `client` (`cliID`,`cliName`) VALUES ('99','Test');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;


--
-- Create Table `composer`
--

DROP TABLE IF EXISTS `composer`;
CREATE TABLE `composer` (
  `cmpID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cmpName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`cmpID`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `composer`
--

/*!40000 ALTER TABLE `composer` DISABLE KEYS */;
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('1',NULL);
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('2','Debbie Wiseman');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('3','Peter Salem');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('4','Rick Clark');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('5','Dominik Scherrer');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('6','Dan Savant');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('7','Simon Hale');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('8','Andrew Skeet');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('9','Dan Jones');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('10','Rob Lane');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('11','John Debney');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('12','Kasabian');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('13','Jack Lowe');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('14','Rene Aubry');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('15','Iain Robertson');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('16','Dom James');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('17','Karl Jenkins');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('18','Fraser T. Smith');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('19','George Fenton');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('20','Benoit Dunaigre');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('21','Rachel Portman');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('22','Ben Bartlett');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('23','Robin Smith');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('24','Toby Hershman');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('25','Adrian Johnston');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('26','Paul Englishby');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('27','Troy Banarzi');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('28','Luis Jardim');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('29','David Rowe');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('30','James Fitzpatrick');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('31','David Arnold');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('32','Dave Arch');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('33','Michael Nyman');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('34','Tom Howe');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('35','Steve Carter');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('36','Paul Clark');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('37','Cliff Masterson');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('38','Trevor Horn');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('39','John Yapp');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('40','Dennis King');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('41','Chris Egan');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('42','Charlie Mole');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('43','Nick Ross');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('44','Mike Dixon');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('45','James Brett');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('46','Steve Lipson');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('47','Michael Bruce');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('48','Dave Stewart');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('49','Biff Stannard');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('50','Martin Koch');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('51','Mark Taylor');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('52','Stuart Andrews');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('53','Roberto Borzoni');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('54','Reuben Fowler');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('55','Andrew Powell');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('56','Maurizio Malagnini');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('57','Matt Brind');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('58','Callum Au');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('59','Dave Hewson');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('60','Mozart');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('61','Thomas Hewitt Jones');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('62','Levi Roots');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('63','Kunihiko Ryo');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('64','Adam Cork');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('65','Graham Stack');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('66','Anna Barry');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('67','Nigel Wright');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('68','David Mitcham');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('69','Will Todd');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('70','Jonathon Rathbone');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('71','Hiroshi');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('72','John Ashton-Thomas');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('73','John Altman');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('74','Eric Whitacre');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('75','John Owens');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('76','Jean-Philippe Rio-Py ');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('77','Vince Webb');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('78','Nelson DeWolfe');
INSERT INTO `composer` (`cmpID`,`cmpName`) VALUES ('79','Test');
/*!40000 ALTER TABLE `composer` ENABLE KEYS */;


--
-- Create Table `engineer`
--

DROP TABLE IF EXISTS `engineer`;
CREATE TABLE `engineer` (
  `engID` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `engName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`engID`),
  UNIQUE KEY `name` (`engName`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `engineer`
--

/*!40000 ALTER TABLE `engineer` DISABLE KEYS */;
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('1',NULL);
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('9','Austin Ince');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('7','Chris Dibble');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('2','Gary Thomas');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('8','Jeremy Murphy');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('4','Mat Bartram');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('13','Mike Cox');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('14','Mike Hatch');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('11','Niall Acott');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('10','Paul Golding');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('12','Robin Sellers');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('5','Simon Rhodes');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('6','Steve McLaughlin');
INSERT INTO `engineer` (`engID`,`engName`) VALUES ('3','Steve Price');
/*!40000 ALTER TABLE `engineer` ENABLE KEYS */;


--
-- Create Table `fixer`
--

DROP TABLE IF EXISTS `fixer`;
CREATE TABLE `fixer` (
  `fixID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fixName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fixID`),
  KEY `name` (`fixName`(10))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `fixer`
--

/*!40000 ALTER TABLE `fixer` DISABLE KEYS */;
INSERT INTO `fixer` (`fixID`,`fixName`) VALUES ('1',NULL);
INSERT INTO `fixer` (`fixID`,`fixName`) VALUES ('2','Roz Colls');
INSERT INTO `fixer` (`fixID`,`fixName`) VALUES ('3','Cool Music');
INSERT INTO `fixer` (`fixID`,`fixName`) VALUES ('4','RPO');
INSERT INTO `fixer` (`fixID`,`fixName`) VALUES ('5','Katy Wilkinson');
INSERT INTO `fixer` (`fixID`,`fixName`) VALUES ('6','LSO');
INSERT INTO `fixer` (`fixID`,`fixName`) VALUES ('7','Dom Kelly');
INSERT INTO `fixer` (`fixID`,`fixName`) VALUES ('8','Roberto Borzoni');
INSERT INTO `fixer` (`fixID`,`fixName`) VALUES ('9','Isobel Griffiths');
/*!40000 ALTER TABLE `fixer` ENABLE KEYS */;


--
-- Create Table `micFault`
--

DROP TABLE IF EXISTS `micFault`;
CREATE TABLE `micFault` (
  `faultID` int(11) NOT NULL AUTO_INCREMENT,
  `micID` int(10) unsigned DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `faultDesc` blob,
  `faultDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `faultOutcome` blob,
  PRIMARY KEY (`faultID`),
  UNIQUE KEY `faultID_UNIQUE` (`faultID`),
  KEY `micFault_ibfk_1_idx` (`micID`),
  KEY `micFault_ibfk_2_idx` (`userID`),
  CONSTRAINT `micFault_ibfk_1` FOREIGN KEY (`micID`) REFERENCES `microphones` (`micID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `micFault_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `users` (`usrID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `micFault`
--

/*!40000 ALTER TABLE `micFault` DISABLE KEYS */;
INSERT INTO `micFault` (`faultID`,`micID`,`userID`,`faultDesc`,`faultDate`,`faultOutcome`) VALUES ('1','1102','1','Broken and unable to take apart.','2013-03-09 18:28:36',NULL);
INSERT INTO `micFault` (`faultID`,`micID`,`userID`,`faultDesc`,`faultDate`,`faultOutcome`) VALUES ('2','1257','6','1257 - Screw Loose Plug End Causing noises during recording','2013-03-18 14:29:32','test');
INSERT INTO `micFault` (`faultID`,`micID`,`userID`,`faultDesc`,`faultDate`,`faultOutcome`) VALUES ('3','1148','1','Level Low','2013-03-18 17:05:04',NULL);
INSERT INTO `micFault` (`faultID`,`micID`,`userID`,`faultDesc`,`faultDate`,`faultOutcome`) VALUES ('4','1001','8','broke','2013-03-22 17:06:31',NULL);
INSERT INTO `micFault` (`faultID`,`micID`,`userID`,`faultDesc`,`faultDate`,`faultOutcome`) VALUES ('5','1060','8','broke','2013-03-22 17:08:45','sorted');
INSERT INTO `micFault` (`faultID`,`micID`,`userID`,`faultDesc`,`faultDate`,`faultOutcome`) VALUES ('6','1000','1','test','2013-03-26 11:11:20','test');
INSERT INTO `micFault` (`faultID`,`micID`,`userID`,`faultDesc`,`faultDate`,`faultOutcome`) VALUES ('7','1000','1','test','2013-03-26 11:22:20','test');
INSERT INTO `micFault` (`faultID`,`micID`,`userID`,`faultDesc`,`faultDate`,`faultOutcome`) VALUES ('8','1000','1','test','2013-03-26 11:42:00','test3');
/*!40000 ALTER TABLE `micFault` ENABLE KEYS */;


--
-- Create Table `micLog`
--

DROP TABLE IF EXISTS `micLog`;
CREATE TABLE `micLog` (
  `miclogID` int(11) NOT NULL AUTO_INCREMENT,
  `micID` int(10) unsigned NOT NULL,
  `sesID` int(10) unsigned DEFAULT NULL,
  `usrID` int(11) NOT NULL,
  `micLogTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logState` varchar(10) NOT NULL,
  PRIMARY KEY (`miclogID`),
  KEY `micLog_ibfk_1_idx` (`micID`),
  KEY `micLog_ibfk_2_idx` (`usrID`),
  KEY `micLog_ibfk_3_idx` (`sesID`),
  CONSTRAINT `micLog_ibfk_1` FOREIGN KEY (`micID`) REFERENCES `microphones` (`micID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `micLog_ibfk_2` FOREIGN KEY (`usrID`) REFERENCES `users` (`usrID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `micLog_ibfk_3` FOREIGN KEY (`sesID`) REFERENCES `session` (`sesID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;

--
-- Data for Table `micLog`
--

/*!40000 ALTER TABLE `micLog` DISABLE KEYS */;
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('1','1000','211','1','2013-03-26 19:38:40','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('2','1000','211','1','2013-03-26 19:38:46','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('3','1000','212','1','2013-03-28 11:27:50','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('4','1010','212','1','2013-03-28 11:27:53','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('5','1012','212','1','2013-03-28 11:27:57','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('6','1257','212','1','2013-03-28 11:28:01','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('7','1234','212','1','2013-03-28 11:28:03','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('9','1010','214','1','2013-03-28 11:29:21','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('10','1012','214','1','2013-03-28 11:29:21','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('11','1234','214','1','2013-03-28 11:29:21','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('12','1257','214','1','2013-03-28 11:29:21','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('13','1256','212','1','2013-03-28 11:29:37','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('14','1256','214','1','2013-03-28 11:29:45','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('15','1000','214','1','2013-03-28 11:31:36','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('16','1000','212','1','2013-03-28 11:31:49','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('17','1000','214','1','2013-03-28 11:32:00','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('18','1200','212','1','2013-03-28 11:34:21','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('19','1201','212','1','2013-03-28 11:34:22','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('20','1200','214','1','2013-03-28 11:34:33','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('21','1201','214','1','2013-03-28 11:34:33','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('22','1019','212','1','2013-03-28 11:35:13','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('23','1020','212','1','2013-03-28 11:35:14','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('24','1021','212','1','2013-03-28 11:35:15','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('25','1022','212','1','2013-03-28 11:35:16','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('26','1023','212','1','2013-03-28 11:35:16','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('27','1024','212','1','2013-03-28 11:35:18','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('28','1019','214','1','2013-03-28 11:35:34','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('29','1020','214','1','2013-03-28 11:35:34','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('30','1021','214','1','2013-03-28 11:35:34','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('31','1022','214','1','2013-03-28 11:35:34','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('32','1023','214','1','2013-03-28 11:35:34','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('33','1024','214','1','2013-03-28 11:35:34','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('34','1000','214','1','2013-03-28 11:35:58','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('35','1010','214','1','2013-03-28 11:35:59','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('36','1012','214','1','2013-03-28 11:36:00','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('37','1019','214','1','2013-03-28 11:36:02','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('38','1020','214','1','2013-03-28 11:36:03','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('39','1021','214','1','2013-03-28 11:36:04','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('40','1022','214','1','2013-03-28 11:36:05','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('41','1023','214','1','2013-03-28 11:36:06','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('42','1024','214','1','2013-03-28 11:36:09','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('43','1200','214','1','2013-03-28 11:36:11','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('44','1201','214','1','2013-03-28 11:36:12','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('45','1234','214','1','2013-03-28 11:36:13','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('46','1256','214','1','2013-03-28 11:36:15','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('47','1257','214','1','2013-03-28 11:36:17','cupboard');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('48','1000','212','1','2013-03-28 11:36:44','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('49','1010','212','1','2013-03-28 11:36:48','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('50','1012','212','1','2013-03-28 11:36:49','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('51','1020','212','1','2013-03-28 11:36:51','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('52','1021','212','1','2013-03-28 11:36:52','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('53','1023','212','1','2013-03-28 11:36:53','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('54','1022','212','1','2013-03-28 11:36:54','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('55','1024','212','1','2013-03-28 11:36:56','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('56','1000','214','1','2013-03-28 11:37:07','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('57','1010','214','1','2013-03-28 11:37:07','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('58','1012','214','1','2013-03-28 11:37:07','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('59','1020','214','1','2013-03-28 11:37:07','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('60','1021','214','1','2013-03-28 11:37:07','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('61','1022','214','1','2013-03-28 11:37:07','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('62','1023','214','1','2013-03-28 11:37:07','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('63','1024','214','1','2013-03-28 11:37:07','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('64','1030','212','1','2013-03-28 11:41:30','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('65','1031','212','1','2013-03-28 11:41:31','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('66','1032','212','1','2013-03-28 11:41:33','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('67','1033','212','1','2013-03-28 11:41:33','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('68','1034','212','1','2013-03-28 11:41:34','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('69','1035','212','1','2013-03-28 11:41:37','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('70','1036','212','1','2013-03-28 11:41:38','session');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('71','1030','214','1','2013-03-28 11:41:50','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('72','1031','214','1','2013-03-28 11:41:50','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('73','1032','214','1','2013-03-28 11:41:50','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('74','1033','214','1','2013-03-28 11:41:50','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('75','1034','214','1','2013-03-28 11:41:50','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('76','1035','214','1','2013-03-28 11:41:50','transfer');
INSERT INTO `micLog` (`miclogID`,`micID`,`sesID`,`usrID`,`micLogTime`,`logState`) VALUES ('77','1036','214','1','2013-03-28 11:41:50','transfer');
/*!40000 ALTER TABLE `micLog` ENABLE KEYS */;


--
-- Create Table `microphones`
--

DROP TABLE IF EXISTS `microphones`;
CREATE TABLE `microphones` (
  `micID` int(10) unsigned NOT NULL,
  `micMake` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `micModel` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `micCupboard` tinyint(1) DEFAULT NULL,
  `micSession` int(10) unsigned DEFAULT NULL,
  `micTransfer` int(10) unsigned DEFAULT NULL,
  `micRepair` tinyint(1) DEFAULT NULL,
  `usrID` int(11) DEFAULT NULL,
  `micTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`micID`),
  UNIQUE KEY `micID_UNIQUE` (`micID`),
  KEY `usrID` (`usrID`),
  KEY `microphones_ibfk_3` (`micTransfer`),
  KEY `microphones_ibfk_1_idx` (`micSession`),
  CONSTRAINT `microphones_ibfk_1` FOREIGN KEY (`micSession`) REFERENCES `backup` (`bakID`),
  CONSTRAINT `microphones_ibfk_2` FOREIGN KEY (`usrID`) REFERENCES `users` (`usrID`),
  CONSTRAINT `microphones_ibfk_3` FOREIGN KEY (`micTransfer`) REFERENCES `backup` (`bakID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `microphones`
--

/*!40000 ALTER TABLE `microphones` DISABLE KEYS */;
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1000','Schoeps','CMC5 - MK4','0','206','204','0','1','2013-03-28 11:37:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1001','Schoeps','CMC5 - MK4','0',NULL,'199','1','8','2013-03-22 17:06:31');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1002','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:46:38');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1003','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:46:42');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1004','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:47:09');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1005','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:47:21');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1006','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:47:00');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1007','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:47:24');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1008','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:46:45');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1009','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:46:48');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1010','Schoeps','CMC5 - MK4','0','206','204','0','1','2013-03-28 11:37:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1011','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:47:15');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1012','Schoeps','CMC5 - MK4','0','206','204','0','1','2013-03-28 11:37:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1013','Schoeps','CMC5 - MK4','0','199',NULL,'0','9','2013-03-21 10:46:56');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1014','Schoeps','CMC5 - MK4','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1015','Schoeps','CMC5 - MK4','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1016','Schoeps','CMC5 - MK4','0','201',NULL,'0','2','2013-03-21 10:22:00');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1017','Schoeps','CMC5 - MK4','0','201',NULL,'0','2','2013-03-21 10:22:02');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1018','Schoeps','CMC5 - MK4','1',NULL,'196','0','5','2013-03-20 16:19:02');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1019','Schoeps','CMC5 - MK4','1',NULL,'206','0','1','2013-03-28 11:36:02');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1020','Schoeps','CMC5 - MK4','0','206','204','0','1','2013-03-28 11:37:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1021','Schoeps','CMC5 - MK4','0','206','204','0','1','2013-03-28 11:37:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1022','Schoeps','CMC5 - MK4','0','206','204','0','1','2013-03-28 11:37:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1023','Schoeps','CMC5 - MK4','0','206','204','0','1','2013-03-28 11:37:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1024','Schoeps','CMC5 - MK4','0','206','204','0','1','2013-03-28 11:37:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1025','Schoeps','CMC5 - MK4','1',NULL,'196','0','5','2013-03-20 16:19:13');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1026','Schoeps','CMC5 - MK21','1',NULL,'185','0','9','2013-03-14 12:23:16');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1027','Schoeps','CMC5 - MK21','1',NULL,'185','0','9','2013-03-14 12:23:09');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1028','Schoeps','CMC5 - MK21','1',NULL,'185','0','9','2013-03-14 12:23:23');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1029','Schoeps','CMC5 - MK40','1',NULL,'188','0','1','2013-03-16 19:02:29');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1030','Schoeps','CMC5 - MK40','0','206','204','0','1','2013-03-28 11:41:50');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1031','Schoeps','CMC5 - MK40','0','206','204','0','1','2013-03-28 11:41:50');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1032','Schoeps','CMC5 - MK40','0','206','204','0','1','2013-03-28 11:41:50');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1033','Schoeps','CMC5 - MK40','0','206','204','0','1','2013-03-28 11:41:50');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1034','Schoeps','CMC5 - MK41','0','206','204','0','1','2013-03-28 11:41:50');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1035','Schoeps','CMC5 - MK41','0','206','204','0','1','2013-03-28 11:41:50');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1036','Schoeps','CMC5 - MK41','0','206','204','0','1','2013-03-28 11:41:50');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1037','Schoeps','CMC5 - MK3','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1038','Schoeps','CMC5 - MK3','1',NULL,'188','0','1','2013-03-16 19:08:14');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1039','Schoeps','CMC5 - MK3','1',NULL,'188','0','1','2013-03-16 19:02:52');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1040','Beyer Dynamic','M67','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1041','DPA','4006','1',NULL,'182','0','9','2013-03-11 16:50:51');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1042','DPA','4006','0','199',NULL,'0','9','2013-03-21 10:47:35');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1043','DPA','4006','1',NULL,'182','0','9','2013-03-11 16:50:54');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1044','DPA','4006','0','199',NULL,'0','9','2013-03-21 10:47:31');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1045','DPA','4006','1',NULL,'191','0','6','2013-03-14 11:47:41');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1046','DPA','4006','1',NULL,'191','0','6','2013-03-14 11:46:14');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1047','Neumann','U89','1',NULL,'188','0','9','2013-03-15 12:47:58');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1048','Neumann','U89','1',NULL,'188','0','9','2013-03-15 12:36:47');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1049','Neumann','U89','1',NULL,'173','0','1','2013-03-06 16:57:30');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1050','Neumann','U89','1',NULL,'176','0','1','2013-03-07 20:55:31');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1051','Neumann','U89','1',NULL,'181','0','1','2013-03-13 11:40:01');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1052','Neumann','U89','1',NULL,'192','0','1','2013-03-17 15:13:30');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1053','Neumann','U89','1',NULL,'192','0','1','2013-03-17 15:13:27');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1054','Neumann','U89','1',NULL,'188','0','1','2013-03-16 19:04:30');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1055','Neumann','U89','1',NULL,'193','0','9','2013-03-18 15:04:09');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1056','Neumann','U89','1',NULL,'182','0','9','2013-03-11 16:51:26');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1057','Neumann','U89','0','199',NULL,'0','9','2013-03-21 10:45:20');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1058','Neumann','U89','0','199',NULL,'0','9','2013-03-21 10:45:26');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1059','Neumann','U89','0','199',NULL,'0','9','2013-03-21 10:45:16');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1060','Neumann','U89','1',NULL,'199','0','8','2013-03-22 17:09:34');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1061','Neumann','KM 184','1',NULL,'196','0','5','2013-03-20 16:19:53');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1062','Neumann','KM 184','1',NULL,'196','0','5','2013-03-20 16:19:58');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1063','Neumann','KM 184','1',NULL,'196','0','5','2013-03-20 16:19:59');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1064','Neumann','KM 184','1',NULL,'196','0','5','2013-03-20 16:20:01');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1065','Neumann','KM 184','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1066','Neumann','KM 184','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1067','Neumann','KM 184','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1068','Neumann','KM 184','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1069','Neumann','KM 184','1',NULL,'183','0','5','2013-03-11 22:08:15');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1070','Neumann','KM 184','1',NULL,'183','0','5','2013-03-11 22:08:17');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1071','Neumann','KM 184','1',NULL,'183','0','5','2013-03-11 22:08:19');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1072','Neumann','KM 184','1',NULL,'183','0','5','2013-03-11 22:08:20');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1073','Neumann','KM 184','1',NULL,'188','0','1','2013-03-16 19:06:04');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1074','AKG','C451','1',NULL,'188','0','1','2013-03-16 19:02:12');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1075','AKG','C451','1',NULL,'188','0','1','2013-03-16 19:02:14');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1076','AKG','C451','1',NULL,'188','0','1','2013-03-16 19:02:18');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1077','AKG','C451','1',NULL,'188','0','1','2013-03-16 19:02:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1078','AKG','C451','1',NULL,'188','0','1','2013-03-16 19:02:20');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1079','AKG','C451','1',NULL,'188','0','1','2013-03-16 19:02:21');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1080','AKG','C414 B-ULS','1',NULL,'184','0','9','2013-03-12 18:54:03');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1081','AKG','C414 B-ULS','0','199',NULL,'0','9','2013-03-21 10:47:03');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1082','AKG','C414 B-ULS','1',NULL,'167','0','6','2013-03-04 11:28:12');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1083','AKG','C414 B-ULS','1',NULL,'167','0','6','2013-03-04 11:28:06');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1084','AKG','C414 EB','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1085','AKG','C414 EB','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1086','AKG','D12','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1087','AKG','D12','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1088','AKG','D12','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1089','AKG','D12','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1090','Neumann','U47','1',NULL,'176','0','1','2013-03-07 20:52:53');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1091','Neumann','U47','0','199',NULL,'0','9','2013-03-21 10:46:23');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1092','Neumann','U47','0','199',NULL,'0','9','2013-03-21 10:46:19');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1093','Neumann','U47','0','199',NULL,'0','9','2013-03-21 10:46:29');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1094','Neumann','U47','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1095','Neumann','U47','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1096','Neumann','U47','1',NULL,'176','0','1','2013-03-07 20:52:59');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1097','Neumann','U47','1',NULL,'174','0','9','2013-03-08 11:25:36');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1098','Neumann','U47','1',NULL,'196','0','5','2013-03-20 16:31:00');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1099','Neumann','U47','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1100','Sennheiser','MKH 406','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1101','Sennheiser','MKH 406','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1102','Electrovoice','RE 20','0',NULL,NULL,'1','1','2013-03-09 18:31:14');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1103','Schoeps','CMTS - 501 - U','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1104','Schoeps','CMTS - 501 - U','1',NULL,'181','0','1','2013-03-13 11:37:43');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1105','Audix','D6','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1106','Audix','D6','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1107','DPA','4011','0','201',NULL,'0','2','2013-03-21 10:21:50');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1108','DPA','4011','0','201',NULL,'0','2','2013-03-21 10:21:52');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1109','DPA','4011','0','199',NULL,'0','9','2013-03-21 10:47:17');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1110','DPA','4011','0','199',NULL,'0','9','2013-03-21 10:47:38');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1111','Calrec','CM 1050C','1',NULL,'184','0','9','2013-03-12 18:51:43');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1112','Calrec','CM 1050C','0','199',NULL,'0','9','2013-03-21 10:46:01');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1113','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1114','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1115','Calrec','CM 1050C','0','199',NULL,'0','9','2013-03-21 10:46:11');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1116','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1117','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1118','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1119','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1120','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1121','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1122','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1123','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1124','Calrec','CM 1050C','0','201',NULL,'0','2','2013-03-21 10:22:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1125','Calrec','CM 1050C','1',NULL,'184','0','9','2013-03-12 18:52:33');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1126','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1127','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1128','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1129','Calrec','CM 1050C','1',NULL,'184','0','9','2013-03-12 18:51:59');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1130','Calrec','CM 1050C','1',NULL,'184','0','9','2013-03-12 18:52:27');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1131','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1132','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1133','Calrec','CM 1050C','0','199',NULL,'0','9','2013-03-21 10:46:21');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1134','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1135','Neumann','U89','1',NULL,'196','0','5','2013-03-20 16:12:29');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1136','Neumann','U89','0','199',NULL,'0','9','2013-03-21 10:45:11');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1137','Neumann','U89','0','199',NULL,'0','9','2013-03-21 10:44:54');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1138','Neumann','U89','0','199',NULL,'0','9','2013-03-21 10:44:57');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1139','Sennheiser','MD 421','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1140','Sennheiser','MD 421','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1141','Sennheiser','MD 421','1',NULL,'188','0','1','2013-03-16 19:05:14');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1142','Sennheiser','MD 421','1',NULL,'184','0','9','2013-03-12 18:52:55');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1143','Sennheiser','MD 421','1',NULL,'184','0','9','2013-03-12 18:52:51');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1144','Sennheiser','MD 421','1',NULL,'184','0','9','2013-03-12 18:53:01');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1145','Coles','4038','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1146','Coles','4038','1',NULL,'188','0','1','2013-03-16 19:04:33');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1147','Coles','4038','1',NULL,'188','0','1','2013-03-16 19:05:47');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1148','Coles','4038','0',NULL,NULL,'1','1','2013-03-18 17:06:26');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1149','Coles','4038','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1150','Coles','4038','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1151','Coles','4038','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1152','Royer','R - 121','1',NULL,'191','0','6','2013-03-14 11:47:28');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1153','Royer','R - 121','1',NULL,'191','0','6','2013-03-14 11:47:29');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1154','Neumann','KM 143','1',NULL,'185','0','9','2013-03-14 12:23:48');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1155','Neumann','KM 143','1',NULL,'185','0','9','2013-03-14 12:23:37');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1156','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1157','Calrec','CM 1050C','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1158','Calrec','CM 1050C','1',NULL,'184','0','9','2013-03-12 18:52:22');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1159','Neumann','U87','1',NULL,'194','0','1','2013-03-20 16:45:52');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1160','Neumann','U87','1',NULL,'194','0','1','2013-03-20 16:45:53');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1161','Neumann','U87','1',NULL,'191','0','6','2013-03-14 11:46:01');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1162','Neumann','U87','0','199',NULL,'0','9','2013-03-21 10:45:53');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1163','Neumann','U87','0','199',NULL,'0','9','2013-03-21 10:46:14');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1164','Neumann','U87','0','199',NULL,'0','9','2013-03-21 10:46:10');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1165','Neumann','U87','0','199',NULL,'0','9','2013-03-21 10:46:05');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1166','Schoeps','MK3','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1167','Schoeps','MK41','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1168','Schoeps','MK41','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1169','Schoeps','MK41','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1191','AKG','D202','1',NULL,'184','0','9','2013-03-12 18:54:57');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1192','AKG','D202','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1193','AKG','D202','1',NULL,'184','0','9','2013-03-12 18:54:59');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1195','Neumann','TLM 50','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1196','Neumann','TLM 50','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1197','Neumann','TLM 50','0','201',NULL,'0','2','2013-03-21 10:22:14');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1198','Neumann','TLM 50','0','201',NULL,'0','2','2013-03-21 10:22:21');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1199','Neumann','M147','1',NULL,'184','0','9','2013-03-12 18:55:24');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1200','Neumann','M147','1',NULL,'206','0','1','2013-03-28 11:36:11');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1201','Neumann','M147','1',NULL,'206','0','1','2013-03-28 11:36:12');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1202','Neumann','M149','1',NULL,'197','0','1','2013-03-20 16:43:35');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1203','Neumann','M149','0','201',NULL,'0','2','2013-03-21 10:22:49');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1204','Neumann','M150','1',NULL,'198','0','5','2013-03-20 16:31:14');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1205','Neumann','M150','1',NULL,'198','0','5','2013-03-20 16:31:15');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1206','Neumann','M150','1',NULL,'198','0','5','2013-03-20 16:31:16');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1207','Shure','SM57','1',NULL,'164','0','7','2013-02-25 15:33:44');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1208','Shure','SM57','1',NULL,'164','0','7','2013-02-25 15:33:48');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1209','Shure','SM57','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1210','Shure','SM57','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1211','Shure','SM57','1',NULL,'188','0','1','2013-03-16 19:04:42');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1212','Shure','SM57','1',NULL,'188','0','1','2013-03-16 19:04:44');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1213','Shure','SM57','1',NULL,'188','0','1','2013-03-16 19:04:49');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1214','Shure','SM57','1',NULL,'188','0','1','2013-03-16 19:04:51');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1215','Shure','SM58','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1216','Shure','SM58','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1217','Shure','SM58','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1218','Shure','SM58','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1219','Shure','SM58','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1220','Shure','SM58','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1221','Shure','SM58','1',NULL,'176','0','5','2013-03-06 10:48:23');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1222','Shure','SM58','1',NULL,'188','0','1','2013-03-16 19:06:51');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1223','Shure','SM58','1',NULL,'188','0','1','2013-03-16 19:04:15');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1224','Shure','SM58','1',NULL,'184','0','9','2013-03-12 18:52:37');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1225','Shure','SM58','1',NULL,'184','0','9','2013-03-12 18:52:40');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1226','Shure','SM58','1',NULL,'188','0','1','2013-03-16 19:04:07');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1227','Shure','SM58','1',NULL,'188','0','1','2013-03-16 19:04:11');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1228','Shure','SM58','1',NULL,'188','0','1','2013-03-16 19:04:19');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1229','Shure','SM58','1',NULL,'188','0','1','2013-03-16 19:04:21');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1230','Shure','SM58','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1233','DPA','4011','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1234','DPA','4011','1',NULL,'206','0','1','2013-03-28 11:36:13');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1235','AKG','414 B-XLS','1',NULL,'196','0','5','2013-03-20 16:11:22');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1236','AKG','414 B-XLS','1',NULL,'196','0','5','2013-03-20 16:11:23');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1237','Royer','R - 121','1',NULL,'188','0','1','2013-03-16 19:05:05');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1238','Royer','R - 121','0','199',NULL,'0','9','2013-03-21 10:46:52');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1242','Neumann','KM 140','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1243','Schoeps','CMC5','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1244','DPA','4060 - BM','1',NULL,'188','0','1','2013-03-17 15:16:19');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1245','Neumann','KM 84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1246','Neumann','KM 84','0','199',NULL,'0','9','2013-03-21 10:46:40');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1247','Neumann','KM 84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1248','Neumann','KM 84','1',NULL,'193','0','9','2013-03-18 15:03:59');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1249','Neumann','KM 84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1250','Neumann','KM 84','0','199',NULL,'0','9','2013-03-21 10:47:27');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1251','Neumann','KM 84','0','199',NULL,'0','9','2013-03-21 10:46:31');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1252','Neumann','KM 84','1',NULL,'197','0','1','2013-03-20 16:43:55');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1253','Neumann','KM 84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1254','Neumann','KM 84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1255','Neumann','KM 84','1',NULL,'197','0','1','2013-03-20 16:44:43');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1256','Neumann','KM 84','1',NULL,'206','0','1','2013-03-28 11:36:15');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1257','Neumann','KM 84','1',NULL,'206','0','1','2013-03-28 11:36:17');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1258','Neumann','KM 83','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1259','Neumann','KM 83','1',NULL,'193','0','9','2013-03-18 15:03:55');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1260','Neumann','KM 83','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1261','Neumann','KM 83','1',NULL,'197','0','1','2013-03-20 16:43:52');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1262','Neumann','KM 83','1',NULL,'197','0','1','2013-03-20 16:45:02');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1263','Neumann','KM 83','1',NULL,'197','0','1','2013-03-20 16:43:49');
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1264','Neumann','84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1265','Neumann','84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1266','Neumann','84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1267','Neumann','84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1268','Neumann','84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1269','Neumann','84','1',NULL,NULL,'0',NULL,NULL);
INSERT INTO `microphones` (`micID`,`micMake`,`micModel`,`micCupboard`,`micSession`,`micTransfer`,`micRepair`,`usrID`,`micTime`) VALUES ('1270','Neumann','84','1',NULL,NULL,'0',NULL,NULL);
/*!40000 ALTER TABLE `microphones` ENABLE KEYS */;


--
-- Create Table `project`
--

DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `prjID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prjName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`prjID`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `project`
--

/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('1',NULL);
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('2','WPC 56');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('3','Call The Midwife');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('4','Miss Marple');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('5','Disney Lion King');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('6','Darius');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('7','Zarina');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('8','The Fear');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('9','Father Brown');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('10','The Making of a Lady');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('11','Arsenal Choir');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('12','Morrisons');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('13','FCMG');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('14','Room on the Broom');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('15','Rachmaninoff');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('16','Spanish');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('17','Caribbean Package Tour');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('18','Hair of the Dog');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('19','Brazil');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('20','Doughnut Ad');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('21','The Wanted');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('22','Direct Line');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('23','Spirit of 45');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('24','Plusnet');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('25','Advert');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('26','Still Life');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('27','Falcon');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('28','Sky Arts Library');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('29','Edmundo Ross');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('30','Dancing on the Edge');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('31','Alain Clark');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('32','Colores');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('33','Anne Nikitin');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('34','Irish Music');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('35','RPO Rock');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('36','Without You');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('37','Tony Carreira');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('38','Sunshine on Leith');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('39','Games Makers Choir');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('40','Muhammed Ali\'s Greatest Fight');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('41','John Barry');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('42','Emirates');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('43','Jobs');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('44','2inch transfers');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('45','Mrs Henderson Musical');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('46','Girl Rising');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('47','Game Podcast');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('48','Baaba Maal');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('49','Strictly Tour 2013');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('50','Jazz Library');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('51','Battleship Potemkin');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('52','Library');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('53','Laura Rossi');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('54','Silver Swan');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('55','Modern Classics');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('56','Renato Zero');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('57','The Last Session');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('58','Privates on Parade');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('59','Mr Selfridge');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('60','Homefront');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('61','Piano');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('62','Angels Share');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('63','BBC Westminster');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('64','Emmanuelle Theme');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('65','Nick Ross Orchestra');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('66','Leslie Bricusse');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('67','Callaborators');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('68','The Spies of Warsaw');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('69','One Chance');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('70','Steps');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('71','Radio 1 Idents');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('72','Little Mix');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('73','Admiral');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('74','The Raven that Refused to Sing');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('75','Alexandra Burke');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('76','Viva Forever');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('77','Cher');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('78','Wizard of Oz');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('79','Nicola Kirsch');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('80','Ryo');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('81','Il Divo');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('82','Megan');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('83','Alexander Rudd');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('84','New York Bakery');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('85','Reuben Fowler Big Band');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('86','Body Farm');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('87','Javier Borda');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('88','Tenors of Rock');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('89','Naomi Scott');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('90','Badanamu');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('91','Tom Le Cancre');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('92','Phantom');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('93','UPMC2');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('94','Big Band');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('95','Pascal');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('96','Murder on the Home Front');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('97','Frozen Planet');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('98','Scapegoat');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('99','Minimalism');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('100','Viva Verdi');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('101','Jennifer Whyte');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('102','Christmas Carols');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('103','Sketch');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('104','Album Re Master');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('105','Admiral Ad');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('106','25 Inauguration Strings + Korean AD');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('107','Symphonic Coldpplay');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('108','Peter and Alice');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('109','Jahmene Douglas');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('110','Tribute to Richard Tauber');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('111','Love Never Dies');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('112','Ice Age');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('113','Ice Age');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('114','Above & Beyond');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('115','Fanfare');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('116','Alice In Wonderland Opera');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('117','Charlie & The Chocolate Factory');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('118','Childs Choir');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('119','Cinematic Portraits');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('120','70\'s Jazz');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('121','More Than BLUES BROTHERS');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('122','Rice Crispies AD');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('123','Paris A Tout Prix');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('124','Carol Kenyon');
INSERT INTO `project` (`prjID`,`prjName`) VALUES ('125','Quirke');
/*!40000 ALTER TABLE `project` ENABLE KEYS */;


--
-- Create Table `recdrive`
--

DROP TABLE IF EXISTS `recdrive`;
CREATE TABLE `recdrive` (
  `recID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `recName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stdID` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`recID`),
  KEY `stdID` (`stdID`),
  CONSTRAINT `recdrive_ibfk_1` FOREIGN KEY (`stdID`) REFERENCES `studio` (`stdID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `recdrive`
--

/*!40000 ALTER TABLE `recdrive` DISABLE KEYS */;
INSERT INTO `recdrive` (`recID`,`recName`,`stdID`) VALUES ('1','1_1','1');
INSERT INTO `recdrive` (`recID`,`recName`,`stdID`) VALUES ('2','1_2','1');
INSERT INTO `recdrive` (`recID`,`recName`,`stdID`) VALUES ('3','1_3','1');
INSERT INTO `recdrive` (`recID`,`recName`,`stdID`) VALUES ('4','2_1','2');
INSERT INTO `recdrive` (`recID`,`recName`,`stdID`) VALUES ('5','2_2','2');
INSERT INTO `recdrive` (`recID`,`recName`,`stdID`) VALUES ('6','2_3','2');
INSERT INTO `recdrive` (`recID`,`recName`,`stdID`) VALUES ('7','3_1','3');
INSERT INTO `recdrive` (`recID`,`recName`,`stdID`) VALUES ('8','3_2','3');
INSERT INTO `recdrive` (`recID`,`recName`,`stdID`) VALUES ('9','3_3','3');
/*!40000 ALTER TABLE `recdrive` ENABLE KEYS */;


--
-- Create Table `session`
--

DROP TABLE IF EXISTS `session`;
CREATE TABLE `session` (
  `sesID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stdID` tinyint(3) unsigned DEFAULT NULL,
  `cliID` int(10) unsigned DEFAULT NULL,
  `prjID` int(10) unsigned DEFAULT NULL,
  `fixID` int(10) unsigned DEFAULT NULL,
  `engID` tinyint(3) unsigned DEFAULT NULL,
  `astID` tinyint(3) unsigned DEFAULT NULL,
  `ssNo` int(10) unsigned DEFAULT NULL,
  `sessDate` date DEFAULT NULL,
  `startTime` time DEFAULT NULL,
  `endTime` time DEFAULT NULL,
  `cmpID` int(10) unsigned DEFAULT NULL,
  `bakID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`sesID`),
  KEY `ssNo` (`ssNo`),
  KEY `sessDate` (`sessDate`),
  KEY `stdID` (`stdID`),
  KEY `prjID` (`prjID`),
  KEY `cliID` (`cliID`),
  KEY `engID` (`engID`),
  KEY `astID` (`astID`),
  KEY `fixID` (`fixID`),
  KEY `cmpID` (`cmpID`),
  KEY `bakID` (`bakID`),
  CONSTRAINT `session_ibfk_1` FOREIGN KEY (`stdID`) REFERENCES `studio` (`stdID`),
  CONSTRAINT `session_ibfk_2` FOREIGN KEY (`prjID`) REFERENCES `project` (`prjID`),
  CONSTRAINT `session_ibfk_3` FOREIGN KEY (`cliID`) REFERENCES `client` (`cliID`),
  CONSTRAINT `session_ibfk_4` FOREIGN KEY (`engID`) REFERENCES `engineer` (`engID`),
  CONSTRAINT `session_ibfk_5` FOREIGN KEY (`astID`) REFERENCES `assistant` (`astID`),
  CONSTRAINT `session_ibfk_6` FOREIGN KEY (`fixID`) REFERENCES `fixer` (`fixID`),
  CONSTRAINT `session_ibfk_7` FOREIGN KEY (`cmpID`) REFERENCES `composer` (`cmpID`),
  CONSTRAINT `session_ibfk_8` FOREIGN KEY (`bakID`) REFERENCES `backup` (`bakID`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `session`
--

/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('1','1','2','2','2','3','2','7866','2013-02-05','10:00:00','22:00:00','2','148');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('2','3','3','3','3','4','3','0','2013-02-05','10:30:00','12:30:00','3','1');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('3','3','4','1','1','2','4','7860','2013-01-24','10:00:00','00:00:00','4','2');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('4','3','3','4','3','2','3','7853','2013-01-19','10:00:00','13:00:00','5','3');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('5','3','5','5','1','4','4','0','2013-01-18','10:00:00','13:00:00','6','4');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('6','3','3','3','3','4','3','7852','2013-01-18','10:30:00','12:30:00','3','5');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('7','3','6','6','1','4','3','7803','2012-11-27','10:00:00','13:00:00','7','6');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('8','1','7','7','1','3','3','7798','2012-11-26','10:00:00','13:00:00','8','7');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('9','3','7','7','1','3','3','7798','2012-11-26','14:00:00','17:00:00','8','8');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('10','3','3','8','3','2','2','7800','2012-11-26','10:00:00','00:00:00','9','21');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('11','3','8','9','1','3','2','7792','2012-11-22','10:00:00','13:00:00','2','20');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('12','3','3','10','3','2','2','7787','2012-11-19','10:00:00','13:00:00','10','19');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('13','3','9','11','1','2','4','7783','2012-11-18','10:00:00','13:00:00','8','18');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('14','3','10','12','1','5','4','7766','2012-11-04','19:00:00','22:00:00','11','17');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('15','3','11','1','1','6','2','7763','2012-11-01','10:00:00','13:00:00','12','16');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('16','3','12','13','1','4','3','7749','2012-10-26','10:00:00','00:00:00','13','15');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('17','3','13','14','1','2','2','7742','2012-10-22','10:00:00','17:00:00','14','10');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('18','3','14','15','1','3','2','7716','2012-10-14','10:00:00','22:00:00','15','14');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('19','3','15','16','1','4','3','7555','2012-07-03','10:00:00','17:00:00','1','9');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('20','3','15','17','1','4','1','0','2012-01-25','10:00:00','17:00:00','1','13');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('21','3','15','18','1','4','1','0','2012-01-18','10:00:00','17:00:00','1','12');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('22','3','15','19','1','4','3','7227','2011-11-01','10:00:00','17:00:00','16','11');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('23','3','16','32','1','3','2','7850','2013-01-15','10:00:00','00:00:00','17','38');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('24','3','17','21','1','3','2','7840','2013-01-08','19:00:00','22:00:00','18','37');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('25','3','18','22','1','4','4','7834','2013-01-02','11:00:00','14:00:00','1','36');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('26','3','19','23','1','3','2','7833','2012-12-18','10:00:00','18:00:00','19','35');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('27','3','18','24','1','2','4','7810','2012-11-30','10:00:00','13:00:00','1','34');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('28','3','20','25','1','2','3','7775','2012-11-12','10:30:00','13:30:00','20','32');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('29','3','21','26','1','7','2','7778','2012-11-13','10:00:00','17:00:00','21','33');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('30','3','10','12','1','5','4','7766','2012-11-04','19:00:00','22:00:00','11','31');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('31','3','3','27','3','2','3','7756','2012-10-29','10:00:00','14:00:00','22','30');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('32','3','22','31','1','2','5','7705','2012-10-08','11:00:00','14:00:00','23','28');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('33','3','23','28','1','2','3','7679','2012-09-21','10:00:00','17:00:00','1','26');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('34','3','15','16','1','2','4','7411','2012-03-27','10:00:00','17:00:00','24','24');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('35','3','24','29','1','2','4','0','2012-01-18','10:00:00','17:00:00','1','23');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('36','3','25','30','1','4','2','7694','2012-10-02','10:00:00','22:00:00','25','27');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('37','3','25','30','1','4','4','7647','2012-09-06','10:00:00','16:00:00','25','25');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('38','3','25','30','1','3','2','7232','2011-11-02','10:00:00','22:00:00','26','22');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('39','3','26','1','1','1','6','0','2012-10-17','10:00:00','17:00:00','1','29');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('40','3','27','33','4','3','2','0','2011-03-18','14:00:00','20:00:00','1','40');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('41','3','15','34','1','4','4','7524','2012-06-14','10:30:00','14:00:00','27','42');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('42','3','28','35','4','2','4','7531','2012-06-20','10:30:00','17:30:00','1','43');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('43','3','29','36','1','1','2','7671','2012-09-17','10:00:00','22:00:00','1','44');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('44','3','30','37','1','4','3','7684','2012-10-16','10:00:00','22:00:00','28','45');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('45','3','31','38','1','3','2','7733','2012-10-18','10:00:00','22:00:00','26','46');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('46','3','32','39','1','3','2','7750','2012-10-25','10:00:00','16:00:00','29','47');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('47','3','33','40','1','3','2','7772','2012-11-08','10:00:00','00:00:00','19','48');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('48','3','28','35','4','2','3','7815','2012-12-07','10:30:00','17:30:00','1','49');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('49','3','28','41','1','2','3','7816','2012-12-10','10:30:00','17:30:00','30','50');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('50','3','28','42','1','2','3','0','2012-12-11','19:00:00','22:00:00','1','51');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('51','3','5','43','1','5','4','7837','2013-01-05','19:00:00','22:00:00','11','52');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('52','3','15','44','1','1','7','0','2010-10-25','10:00:00','17:00:00','1','39');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('53','3','19','45','1','3','2','7476','2012-05-12','10:00:00','00:00:00','19','41');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('54','1','3','96','3','2','3','0','2013-02-08','10:30:00','14:30:00','10','149');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('55','1','34','52','5','3','2','7874','2013-02-14','10:00:00','22:00:00','53','156');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('56','1','35','46','1','8','1','0','2013-02-03','10:00:00','13:00:00','21','53');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('57','1','36','47','1','2','4','7855','2013-01-28','10:00:00','22:00:00','1','54');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('58','1','37','48','1','4','3','7857','2013-01-23','11:00:00','14:00:00','31','55');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('59','1','2','2','1','3','2','7847','2013-01-18','10:00:00','22:00:00','2','56');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('60','1','38','49','1','3','4','7842','2013-01-11','10:00:00','22:00:00','32','57');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('61','1','3','3','3','3','2','7838','2013-01-08','10:30:00','13:30:00','3','58');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('62','1','14','50','1','3','2','7835','2013-01-03','10:00:00','18:00:00','1','59');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('63','1','39','51','1','9','3','7830','2012-12-17','09:00:00','17:00:00','33','60');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('64','1','14','1','1','4','4','7829','2012-12-16','10:00:00','22:00:00','34','61');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('65','1','34','52','1','3','2','7824','2012-12-13','10:00:00','22:00:00','35','62');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('66','1','3','3','3','3','2','7821','2012-12-11','10:30:00','13:30:00','3','63');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('67','1','3','53','1','3','2','7818','2012-12-10','10:00:00','19:00:00','15','64');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('68','1','40','54','1','4','2','7820','2012-12-07','19:00:00','21:00:00','36','66');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('69','1','23','55','1','4','3','7808','2012-11-30','10:00:00','21:30:00','37','67');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('70','1','41','56','1','4','2','7768','2012-11-06','10:00:00','18:00:00','38','68');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('71','1','42','57','1','4','4','7753','2012-10-29','11:00:00','18:00:00','39','69');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('72','1','43','58','1','2','4','7746','2012-10-26','14:30:00','17:30:00','40','70');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('73','1','3','3','3','3','3','7740','2012-10-20','10:30:00','13:30:00','3','71');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('74','1','44','1','1','8','4','7736','2012-10-16','14:00:00','17:00:00','41','72');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('75','1','3','3','3','3','3','7707','2012-10-08','10:30:00','13:30:00','3','73');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('76','1','3','59','3','10','2','7680','2012-09-22','10:30:00','13:30:00','42','74');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('77','1','8','9','2','3','3','7651','2012-09-07','10:00:00','22:00:00','2','75');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('78','1','45','60','1','11','6','7650','2012-09-06','14:00:00','17:00:00','1','76');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('79','1','15','61','1','2','1','0','2012-07-24','10:00:00','00:00:00','1','77');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('80','1','19','45','1','3','2','7336','2012-01-23','14:00:00','17:00:00','19','78');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('81','1','19','62','1','3','2','7289','2012-12-09','10:00:00','22:00:00','19','65');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('82','1','46','63','1','3','2','7284','2011-12-06','10:00:00','22:00:00','19','80');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('83','1','47','1','1','3','8','0','2011-03-15','10:00:00','22:00:00','1','81');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('84','1','15','64','1','2','1','0','2011-12-16','10:00:00','00:00:00','1','79');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('85','1','48','65','1','3','2','7013','2011-07-18','10:00:00','18:00:00','43','101');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('86','1','49','66','1','2','4','7196','2011-10-17','10:00:00','17:00:00','44','100');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('87','1','19','67','1','3','4','7209','2011-10-21','10:00:00','17:00:00','19','99');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('88','1','3','68','1','4','4','7652','2012-09-08','10:00:00','22:00:00','10','98');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('89','1','50','69','1','4','2','7653','2012-09-10','10:00:00','22:00:00','45','97');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('90','1','51','70','1','4','2','7656','2012-09-11','10:00:00','22:00:00','46','96');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('91','1','52','71','1','2','4','7670','2012-09-17','14:00:00','18:00:00','1','95');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('92','1','53','1','1','4','4','7672','2012-09-20','10:00:00','13:00:00','47','94');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('93','1','2','9','1','4','2','7681','2012-09-25','09:00:00','21:00:00','2','93');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('94','1','54','72','1','4','2','7685','2012-09-26','18:00:00','21:00:00','37','92');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('95','1','55','73','1','11','4','7702','2012-10-02','13:30:00','16:30:00','1','91');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('96','1','2','9','1','3','2','7714','2012-10-12','09:00:00','21:00:00','2','90');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('97','1','56','74','1','3','3','7730','2012-10-17','13:00:00','17:00:00','48','88');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('98','1','54','75','1','4','3','7739','2012-10-19','10:00:00','13:00:00','49','87');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('99','1','2','9','1','3','2','7767','2012-11-05','09:00:00','21:00:00','2','85');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('100','1','57','76','1','3','2','7765','2012-11-03','09:00:00','21:00:00','50','86');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('101','1','58','1','1','4','3','7784','2012-11-19','10:00:00','22:00:00','1','84');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('102','1','3','3','3','3','2','7790','2012-11-21','10:30:00','13:30:00','3','83');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('103','1','59','77','1','3','2','7861','2013-01-31','10:30:00','13:30:00','51','82');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('104','1','60','78','1','4','4','7721','2012-10-13','15:00:00','18:00:00','52','89');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('105','1','31','69','1','4','3','0','2013-02-12','10:00:00','22:00:00','45','151');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('107','2','84','13','1','8','4','0','2013-02-16','11:00:00','14:00:00','1','158');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('108','3','62','106','6','4','3','7877','2013-02-16','15:00:00','22:00:00','63','157');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('109','1','54','81','1','2','2','7566','2012-07-09','18:30:00','22:30:00','49','115');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('110','1','18','82','1','3','2','7706','2012-10-04','16:00:00','19:00:00','1','112');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('111','1','34','52','1','3','3','7689','2012-10-05','10:00:00','14:00:00','53','111');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('112','1','63','1','1','4','3','7747','2012-10-23','19:00:00','22:00:00','1','110');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('113','1','8','9','1','3','2','7793','2012-11-23','09:00:00','21:00:00','2','109');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('114','1','3','3','1','3','2','7798','2012-11-26','19:30:00','22:30:00','3','108');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('115','1','4','1','1','2','4','7811','2012-12-04','10:00:00','17:00:00','4','107');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('116','1','57','76','1','4','2','7813','2012-12-05','10:30:00','13:30:00','50','106');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('117','1','14','83','1','2','3','7845','2013-01-15','10:00:00','22:00:00','15','105');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('118','1','64','84','1','2','3','7851','2013-01-16','11:00:00','14:00:00','1','104');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('119','1','65','85','1','3','2','7848','2013-01-21','10:00:00','18:00:00','54','102');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('120','1','34','52','1','4','4','7846','2013-01-17','10:00:00','17:00:00','53','103');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('121','1','66','1','1','1','2','7615','2012-08-17','14:00:00','17:00:00','55','113');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('122','1','46','86','1','1','1','7063','2012-07-29','10:00:00','22:00:00','56','114');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('123','1','67','87','1','4','4','7530','2012-06-21','14:00:00','17:00:00','1','116');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('124','1','67','87','1','3','2','7359','2012-02-23','15:00:00','18:00:00','1','118');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('125','1','67','87','1','4','4','7386','2012-03-15','16:00:00','19:00:00','1','117');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('126','2','19','45','1','4','4','0','2011-04-12','14:00:00','18:00:00','19','129');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('127','2','19','45','1','4','3','7502','2012-05-28','17:00:00','20:00:00','19','128');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('128','2','68','88','1','4','3','7607','2012-08-14','10:00:00','22:00:00','57','127');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('129','2','69','1','1','2','1','7693','2012-10-02','10:00:00','15:00:00','1','126');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('130','2','61','79','1','2','1','7710','2012-10-10','14:00:00','17:00:00','30','125');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('131','2','70','89','1','2','4','7751','2012-10-31','15:00:00','18:00:00','1','124');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('132','2','4','1','1','2','4','7770','2012-11-06','10:00:00','17:00:00','4','123');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('133','2','42','1','1','4','1','7819','2012-12-10','14:00:00','17:00:00','39','122');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('134','2','12','90','1','4','4','7827','2012-12-14','18:00:00','21:00:00','1','121');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('135','2','42','1','1','4','4','7832','2012-12-19','14:00:00','17:00:00','39','120');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('136','2','42','1','1','4','4','7843','2013-01-15','14:00:00','17:00:00','39','119');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('137','2','71','91','1','2','4','7481','2012-05-19','10:00:00','22:00:00','1','135');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('138','2','72','92','1','4','4','7350','2012-02-13','14:00:00','21:00:00','1','136');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('139','2','73','93','1','2','3','7689','2012-10-03','10:00:00','22:00:00','1','134');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('140','2','33','40','1','3','2','7773','2012-11-09','10:00:00','22:00:00','19','132');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('141','2','21','26','1','7','2','7776','2012-11-15','10:00:00','22:00:00','21','131');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('142','2','74','94','1','3','2','7805','2012-11-28','10:00:00','22:00:00','58','130');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('143','2','75','95','1','4','4','7741','2012-10-22','11:00:00','14:00:00','1','133');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('144','1','3','96','1','4','3','7760','2012-10-31','10:00:00','18:00:00','10','147');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('145','2','19','97','1','3','2','0','2010-09-23','10:00:00','22:00:00','19','146');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('146','2','76','98','1','11','3','7354','2012-02-16','10:00:00','22:00:00','25','145');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('147','2','77','52','1','3','2','7364','2012-02-24','10:00:00','22:00:00','59','144');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('148','2','78','99','1','3','2','7399','2012-03-21','10:00:00','22:00:00','1','143');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('149','2','79','100','1','3','3','7662','2012-09-14','10:00:00','00:00:00','1','142');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('150','2','80','101','1','11','6','7668','2012-09-15','10:00:00','22:00:00','60','141');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('151','2','13','14','1','2','4','7744','2012-10-25','10:00:00','22:00:00','14','140');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('152','2','81','102','1','2','4','7797','2012-11-23','10:30:00','13:30:00','61','139');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('153','2','7','7','1','3','2','7802','2012-11-28','19:00:00','22:00:00','8','138');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('154','2','82','103','1','2','3','0','2013-02-01','14:00:00','17:00:00','1','137');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('155','2','83','1','1','2','4','0','2013-02-12','15:00:00','00:00:00','62','152');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('156','2','83','1','1','2','4','0','2013-02-13','15:00:00','00:00:00','62','155');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('157','2','83','1','1','2','4','0','2013-02-14','12:00:00','22:00:00','62','154');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('158','2','15','104','1','1','3','0','2013-02-11','14:00:00','17:00:00','1','150');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('159','3','55','105','1','4','3','0','2013-02-13','10:00:00','22:00:00','1','153');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('160','3','28','107','4','3','2','7878','2013-02-18','10:30:00','17:30:00','41','161');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('161','2','83','1','1','2','4','0','2013-02-15','10:30:00','12:30:00','62','159');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('162','1','3','3','3','4','3','7876','2013-02-18','10:30:00','13:30:00','3','160');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('163','3','43','108','1','4','4','7880','2013-02-22','10:00:00','13:00:00','64','162');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('164','2','2','2','1','3','3','0','2013-02-22','15:00:00','18:00:00','2','163');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('165','1','2','2','2','3','3','0','2013-02-25','10:00:00','22:00:00','2','164');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('166','1','59','109','2','4','3','0','2013-02-26','09:00:00','22:00:00','65','165');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('168','1','86','115','4','3','2','7883','2013-03-01','10:00:00','17:00:00','31','167');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('169','3','84','13','1','4','3','7884','2013-03-02','14:00:00','17:00:00','1','168');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('171','2','87','110','1','4','4','0','2013-01-08','10:00:00','13:00:00','66','170');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('172','3','16','32','1','3','2','7885','2013-03-04','10:00:00','22:00:00','17','171');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('174','1','88','116','1','4','4','7886','2013-03-06','12:00:00','15:00:00','69','173');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('175','1','46','112','1','2','3','7887','2013-03-07','19:00:00','21:00:00','68','174');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('176','2','69','1','1','4','4','7888','2013-03-07','10:00:00','18:00:00','1','175');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('177','3','46','113','1','2','3','7889','2013-03-07','14:30:00','17:30:00','68','176');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('181','3','89','118','1','3','2','7890','2013-03-08','12:00:00','18:00:00','72','178');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('182','1','50','69','1','4','3','0','2013-03-09','15:00:00','20:00:00','45','179');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('183','1','90','114','7','3','2','0','2013-03-10','10:00:00','17:00:00','41','180');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('184','2','83','1','1','2','4','0','2013-03-09','12:00:00','00:00:00','62','181');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('185','2','83','1','1','2','4','0','2013-03-10','12:00:00','00:00:00','62','181');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('186','3','91','1','1','13','2','0','2013-03-11','10:00:00','14:00:00','70','182');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('187','2','83','1','1','2','4','0','2013-03-11','12:00:00','00:00:00','62','181');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('188','1','34','119','8','4','3','7895','2013-03-11','10:00:00','22:00:00','76','183');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('189','1','15','120','7','2','2','7896','2013-03-12','10:00:00','17:00:00','73','184');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('190','1','92','1','1','14','2','0','2013-03-13','12:30:00','21:30:00','74','185');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('191','1','93','1','1','14','2','0','2013-03-13','21:30:00','22:30:00','74','186');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('192','2','15','1','1','2','2','0','2013-03-14','10:00:00','20:00:00','73','190');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('193','1','94','117','1','4','4','7905','2013-03-15','18:00:00','22:00:00','75','188');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('194','1','94','117','1','4','4','0','2013-03-16','08:00:00','20:00:00','75','188');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('196','3','95','122','1','4','3','0','2013-03-14','18:00:00','20:00:00','1','189');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('197','3','96','121','9','4','4','7902','2013-03-13','14:00:00','17:00:00','77','191');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('198','1','3','1','3','4','3','0','2013-03-17','10:30:00','13:30:00','10','192');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('199','1','3','4','3','2','4','7903','2013-03-18','10:00:00','13:00:00','5','193');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('200','3','39','51','1','9','3','0','2013-03-18','09:00:00','17:00:00','33','194');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('201','3','39','51','1','9','3','0','2013-03-19','10:00:00','22:00:00','33','194');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('202','1','3','125','3','4','3','7912','2013-03-20','10:00:00','14:30:00','10','196');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('203','3','15','1','1','2','4','0','2013-03-20','10:00:00','17:00:00','78','197');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('204','1','97','123','9','4','4','7890','2013-03-22','14:00:00','17:00:00','1','198');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('205','3','46','112','1','2','3','0','2013-03-22','09:00:00','13:00:00','68','199');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('206','1','3','59','1','4','4','0','2013-01-20','10:00:00','22:00:00','42','200');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('207','1','98','124','1','3','2','0','2013-03-21','14:00:00','17:00:00','1','201');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('211','1','4','1','1','3','8','0','2013-03-26','10:00:00','00:00:00','1','203');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('212','1','99','1','1','2','4','0','2013-03-28','10:00:00','22:00:00','79','204');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('213','1','99','1','1','3','2','0','2013-03-04','10:00:00','00:00:00','79','205');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('214','1','99','1','1','6','2','0','2013-04-04','10:00:00','22:00:00','79','206');
INSERT INTO `session` (`sesID`,`stdID`,`cliID`,`prjID`,`fixID`,`engID`,`astID`,`ssNo`,`sessDate`,`startTime`,`endTime`,`cmpID`,`bakID`) VALUES ('215','1','99','1','1','8','3','0','2013-04-13','10:00:00','22:00:00','79','207');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;


--
-- Create Table `sessmics`
--

DROP TABLE IF EXISTS `sessmics`;
CREATE TABLE `sessmics` (
  `sessmicsID` int(10) unsigned NOT NULL,
  `sessmicList` text,
  PRIMARY KEY (`sessmicsID`),
  CONSTRAINT `sessmics_ibfk_1` FOREIGN KEY (`sessmicsID`) REFERENCES `backup` (`bakID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `sessmics`
--

/*!40000 ALTER TABLE `sessmics` DISABLE KEYS */;
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('161','a:1:{i:0;s:4:\"1000\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('162','a:3:{i:0;s:4:\"1057\";i:1;s:4:\"1135\";i:2;s:4:\"1138\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('163','a:3:{i:0;s:4:\"1112\";i:1;s:4:\"1136\";i:2;s:4:\"1137\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('164','a:27:{i:0;s:4:\"1018\";i:1;s:4:\"1019\";i:2;s:4:\"1020\";i:3;s:4:\"1021\";i:4;s:4:\"1022\";i:5;s:4:\"1023\";i:6;s:4:\"1024\";i:7;s:4:\"1025\";i:8;s:4:\"1073\";i:9;s:4:\"1074\";i:10;s:4:\"1076\";i:11;s:4:\"1078\";i:12;s:4:\"1080\";i:13;s:4:\"1081\";i:14;s:4:\"1098\";i:15;s:4:\"1124\";i:16;s:4:\"1125\";i:17;s:4:\"1130\";i:18;s:4:\"1133\";i:19;s:4:\"1159\";i:20;s:4:\"1160\";i:21;s:4:\"1207\";i:22;s:4:\"1208\";i:23;s:4:\"1211\";i:24;s:4:\"1212\";i:25;s:4:\"1237\";i:26;s:4:\"1238\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('165','a:16:{i:0;s:4:\"1018\";i:1;s:4:\"1019\";i:2;s:4:\"1020\";i:3;s:4:\"1021\";i:4;s:4:\"1022\";i:5;s:4:\"1023\";i:6;s:4:\"1024\";i:7;s:4:\"1025\";i:8;s:4:\"1057\";i:9;s:4:\"1058\";i:10;s:4:\"1073\";i:11;s:4:\"1124\";i:12;s:4:\"1135\";i:13;s:4:\"1138\";i:14;s:4:\"1205\";i:15;s:4:\"1206\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('167','a:38:{i:0;s:4:\"1041\";i:1;s:4:\"1042\";i:2;s:4:\"1043\";i:3;s:4:\"1052\";i:4;s:4:\"1054\";i:5;s:4:\"1057\";i:6;s:4:\"1058\";i:7;s:4:\"1059\";i:8;s:4:\"1074\";i:9;s:4:\"1075\";i:10;s:4:\"1076\";i:11;s:4:\"1077\";i:12;s:4:\"1078\";i:13;s:4:\"1079\";i:14;s:4:\"1080\";i:15;s:4:\"1081\";i:16;s:4:\"1082\";i:17;s:4:\"1083\";i:18;s:4:\"1097\";i:19;s:4:\"1098\";i:20;s:4:\"1124\";i:21;s:4:\"1135\";i:22;s:4:\"1138\";i:23;s:4:\"1159\";i:24;s:4:\"1160\";i:25;s:4:\"1161\";i:26;s:4:\"1204\";i:27;s:4:\"1205\";i:28;s:4:\"1206\";i:29;s:4:\"1246\";i:30;s:4:\"1248\";i:31;s:4:\"1250\";i:32;s:4:\"1252\";i:33;s:4:\"1255\";i:34;s:4:\"1256\";i:35;s:4:\"1257\";i:36;s:4:\"1259\";i:37;s:4:\"1262\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('168','a:11:{i:0;s:4:\"1044\";i:1;s:4:\"1045\";i:2;s:4:\"1047\";i:3;s:4:\"1053\";i:4;s:4:\"1060\";i:5;s:4:\"1112\";i:6;s:4:\"1136\";i:7;s:4:\"1137\";i:8;s:4:\"1204\";i:9;s:4:\"1205\";i:10;s:4:\"1206\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('171','a:15:{i:0;s:4:\"1044\";i:1;s:4:\"1045\";i:2;s:4:\"1053\";i:3;s:4:\"1060\";i:4;s:4:\"1081\";i:5;s:4:\"1107\";i:6;s:4:\"1108\";i:7;s:4:\"1112\";i:8;s:4:\"1136\";i:9;s:4:\"1137\";i:10;s:4:\"1159\";i:11;s:4:\"1204\";i:12;s:4:\"1205\";i:13;s:4:\"1206\";i:14;s:4:\"1238\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('173','a:35:{i:0;s:4:\"1011\";i:1;s:4:\"1049\";i:2;s:4:\"1051\";i:3;s:4:\"1052\";i:4;s:4:\"1054\";i:5;s:4:\"1055\";i:6;s:4:\"1057\";i:7;s:4:\"1058\";i:8;s:4:\"1059\";i:9;s:4:\"1075\";i:10;s:4:\"1076\";i:11;s:4:\"1078\";i:12;s:4:\"1079\";i:13;s:4:\"1097\";i:14;s:4:\"1104\";i:15;s:4:\"1109\";i:16;s:4:\"1110\";i:17;s:4:\"1125\";i:18;s:4:\"1135\";i:19;s:4:\"1137\";i:20;s:4:\"1138\";i:21;s:4:\"1147\";i:22;s:4:\"1152\";i:23;s:4:\"1160\";i:24;s:4:\"1161\";i:25;s:4:\"1162\";i:26;s:4:\"1163\";i:27;s:4:\"1197\";i:28;s:4:\"1198\";i:29;s:4:\"1211\";i:30;s:4:\"1212\";i:31;s:4:\"1237\";i:32;s:4:\"1255\";i:33;s:4:\"1256\";i:34;s:4:\"1257\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('174','a:11:{i:0;s:4:\"1055\";i:1;s:4:\"1057\";i:2;s:4:\"1058\";i:3;s:4:\"1059\";i:4;s:4:\"1097\";i:5;s:4:\"1125\";i:6;s:4:\"1135\";i:7;s:4:\"1137\";i:8;s:4:\"1138\";i:9;s:4:\"1197\";i:10;s:4:\"1198\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('176','a:38:{i:0;s:4:\"1009\";i:1;s:4:\"1018\";i:2;s:4:\"1019\";i:3;s:4:\"1020\";i:4;s:4:\"1021\";i:5;s:4:\"1022\";i:6;s:4:\"1023\";i:7;s:4:\"1024\";i:8;s:4:\"1025\";i:9;s:4:\"1044\";i:10;s:4:\"1045\";i:11;s:4:\"1047\";i:12;s:4:\"1048\";i:13;s:4:\"1050\";i:14;s:4:\"1053\";i:15;s:4:\"1056\";i:16;s:4:\"1060\";i:17;s:4:\"1090\";i:18;s:4:\"1091\";i:19;s:4:\"1092\";i:20;s:4:\"1093\";i:21;s:4:\"1096\";i:22;s:4:\"1098\";i:23;s:4:\"1107\";i:24;s:4:\"1108\";i:25;s:4:\"1112\";i:26;s:4:\"1136\";i:27;s:4:\"1159\";i:28;s:4:\"1164\";i:29;s:4:\"1165\";i:30;s:4:\"1204\";i:31;s:4:\"1205\";i:32;s:4:\"1206\";i:33;s:4:\"1221\";i:34;s:4:\"1238\";i:35;s:4:\"1248\";i:36;s:4:\"1252\";i:37;s:4:\"1259\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('178','a:11:{i:0;s:4:\"1044\";i:1;s:4:\"1045\";i:2;s:4:\"1053\";i:3;s:4:\"1056\";i:4;s:4:\"1060\";i:5;s:4:\"1112\";i:6;s:4:\"1133\";i:7;s:4:\"1136\";i:8;s:4:\"1204\";i:9;s:4:\"1205\";i:10;s:4:\"1206\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('179','a:3:{i:0;s:4:\"1034\";i:1;s:4:\"1202\";i:2;s:4:\"1244\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('180','a:22:{i:0;s:4:\"1016\";i:1;s:4:\"1018\";i:2;s:4:\"1019\";i:3;s:4:\"1020\";i:4;s:4:\"1021\";i:5;s:4:\"1022\";i:6;s:4:\"1023\";i:7;s:4:\"1024\";i:8;s:4:\"1025\";i:9;s:4:\"1042\";i:10;s:4:\"1046\";i:11;s:4:\"1069\";i:12;s:4:\"1070\";i:13;s:4:\"1071\";i:14;s:4:\"1072\";i:15;s:4:\"1111\";i:16;s:4:\"1160\";i:17;s:4:\"1204\";i:18;s:4:\"1205\";i:19;s:4:\"1206\";i:20;s:4:\"1235\";i:21;s:4:\"1236\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('181','a:9:{i:0;s:4:\"1051\";i:1;s:4:\"1093\";i:2;s:4:\"1104\";i:3;s:4:\"1159\";i:4;s:4:\"1161\";i:5;s:4:\"1203\";i:6;s:4:\"1238\";i:7;s:4:\"1252\";i:8;s:4:\"1259\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('182','a:13:{i:0;s:4:\"1041\";i:1;s:4:\"1043\";i:2;s:4:\"1044\";i:3;s:4:\"1045\";i:4;s:4:\"1053\";i:5;s:4:\"1056\";i:6;s:4:\"1060\";i:7;s:4:\"1112\";i:8;s:4:\"1133\";i:9;s:4:\"1136\";i:10;s:4:\"1204\";i:11;s:4:\"1205\";i:12;s:4:\"1206\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('183','a:35:{i:0;s:4:\"1016\";i:1;s:4:\"1018\";i:2;s:4:\"1019\";i:3;s:4:\"1020\";i:4;s:4:\"1021\";i:5;s:4:\"1022\";i:6;s:4:\"1023\";i:7;s:4:\"1024\";i:8;s:4:\"1025\";i:9;s:4:\"1029\";i:10;s:4:\"1031\";i:11;s:4:\"1042\";i:12;s:4:\"1046\";i:13;s:4:\"1057\";i:14;s:4:\"1059\";i:15;s:4:\"1069\";i:16;s:4:\"1070\";i:17;s:4:\"1071\";i:18;s:4:\"1072\";i:19;s:4:\"1078\";i:20;s:4:\"1107\";i:21;s:4:\"1108\";i:22;s:4:\"1111\";i:23;s:4:\"1141\";i:24;s:4:\"1142\";i:25;s:4:\"1143\";i:26;s:4:\"1144\";i:27;s:4:\"1160\";i:28;s:4:\"1197\";i:29;s:4:\"1198\";i:30;s:4:\"1204\";i:31;s:4:\"1205\";i:32;s:4:\"1206\";i:33;s:4:\"1224\";i:34;s:4:\"1225\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('184','a:35:{i:0;s:4:\"1029\";i:1;s:4:\"1031\";i:2;s:4:\"1074\";i:3;s:4:\"1076\";i:4;s:4:\"1078\";i:5;s:4:\"1080\";i:6;s:4:\"1081\";i:7;s:4:\"1111\";i:8;s:4:\"1112\";i:9;s:4:\"1115\";i:10;s:4:\"1124\";i:11;s:4:\"1125\";i:12;s:4:\"1129\";i:13;s:4:\"1130\";i:14;s:4:\"1133\";i:15;s:4:\"1141\";i:16;s:4:\"1142\";i:17;s:4:\"1143\";i:18;s:4:\"1144\";i:19;s:4:\"1158\";i:20;s:4:\"1160\";i:21;s:4:\"1162\";i:22;s:4:\"1164\";i:23;s:4:\"1165\";i:24;s:4:\"1191\";i:25;s:4:\"1193\";i:26;s:4:\"1199\";i:27;s:4:\"1201\";i:28;s:4:\"1224\";i:29;s:4:\"1225\";i:30;s:4:\"1226\";i:31;s:4:\"1237\";i:32;s:4:\"1255\";i:33;s:4:\"1256\";i:34;s:4:\"1257\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('185','a:9:{i:0;s:4:\"1026\";i:1;s:4:\"1027\";i:2;s:4:\"1028\";i:3;s:4:\"1115\";i:4;s:4:\"1124\";i:5;s:4:\"1154\";i:6;s:4:\"1155\";i:7;s:4:\"1205\";i:8;s:4:\"1206\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('188','a:49:{i:0;s:4:\"1006\";i:1;s:4:\"1009\";i:2;s:4:\"1013\";i:3;s:4:\"1029\";i:4;s:4:\"1031\";i:5;s:4:\"1034\";i:6;s:4:\"1035\";i:7;s:4:\"1038\";i:8;s:4:\"1039\";i:9;s:4:\"1047\";i:10;s:4:\"1048\";i:11;s:4:\"1052\";i:12;s:4:\"1053\";i:13;s:4:\"1054\";i:14;s:4:\"1055\";i:15;s:4:\"1057\";i:16;s:4:\"1059\";i:17;s:4:\"1073\";i:18;s:4:\"1074\";i:19;s:4:\"1075\";i:20;s:4:\"1076\";i:21;s:4:\"1077\";i:22;s:4:\"1078\";i:23;s:4:\"1079\";i:24;s:4:\"1107\";i:25;s:4:\"1115\";i:26;s:4:\"1124\";i:27;s:4:\"1137\";i:28;s:4:\"1138\";i:29;s:4:\"1141\";i:30;s:4:\"1146\";i:31;s:4:\"1147\";i:32;s:4:\"1164\";i:33;s:4:\"1165\";i:34;s:4:\"1211\";i:35;s:4:\"1212\";i:36;s:4:\"1213\";i:37;s:4:\"1214\";i:38;s:4:\"1222\";i:39;s:4:\"1223\";i:40;s:4:\"1226\";i:41;s:4:\"1227\";i:42;s:4:\"1228\";i:43;s:4:\"1229\";i:44;s:4:\"1237\";i:45;s:4:\"1238\";i:46;s:4:\"1244\";i:47;s:4:\"1248\";i:48;s:4:\"1252\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('189','a:8:{i:0;s:4:\"1042\";i:1;s:4:\"1044\";i:2;s:4:\"1057\";i:3;s:4:\"1058\";i:4;s:4:\"1060\";i:5;s:4:\"1133\";i:6;s:4:\"1135\";i:7;s:4:\"1136\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('191','a:19:{i:0;s:4:\"1042\";i:1;s:4:\"1044\";i:2;s:4:\"1045\";i:3;s:4:\"1046\";i:4;s:4:\"1057\";i:5;s:4:\"1058\";i:6;s:4:\"1074\";i:7;s:4:\"1075\";i:8;s:4:\"1076\";i:9;s:4:\"1077\";i:10;s:4:\"1079\";i:11;s:4:\"1133\";i:12;s:4:\"1152\";i:13;s:4:\"1153\";i:14;s:4:\"1159\";i:15;s:4:\"1160\";i:16;s:4:\"1161\";i:17;s:4:\"1237\";i:18;s:4:\"1238\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('192','a:36:{i:0;s:4:\"1000\";i:1;s:4:\"1004\";i:2;s:4:\"1005\";i:3;s:4:\"1011\";i:4;s:4:\"1016\";i:5;s:4:\"1018\";i:6;s:4:\"1019\";i:7;s:4:\"1020\";i:8;s:4:\"1021\";i:9;s:4:\"1022\";i:10;s:4:\"1023\";i:11;s:4:\"1024\";i:12;s:4:\"1025\";i:13;s:4:\"1042\";i:14;s:4:\"1044\";i:15;s:4:\"1052\";i:16;s:4:\"1053\";i:17;s:4:\"1055\";i:18;s:4:\"1057\";i:19;s:4:\"1059\";i:20;s:4:\"1061\";i:21;s:4:\"1062\";i:22;s:4:\"1063\";i:23;s:4:\"1064\";i:24;s:4:\"1115\";i:25;s:4:\"1137\";i:26;s:4:\"1138\";i:27;s:4:\"1162\";i:28;s:4:\"1163\";i:29;s:4:\"1164\";i:30;s:4:\"1165\";i:31;s:4:\"1197\";i:32;s:4:\"1198\";i:33;s:4:\"1204\";i:34;s:4:\"1205\";i:35;s:4:\"1206\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('193','a:16:{i:0;s:4:\"1055\";i:1;s:4:\"1057\";i:2;s:4:\"1109\";i:3;s:4:\"1110\";i:4;s:4:\"1115\";i:5;s:4:\"1163\";i:6;s:4:\"1164\";i:7;s:4:\"1197\";i:8;s:4:\"1198\";i:9;s:4:\"1248\";i:10;s:4:\"1252\";i:11;s:4:\"1255\";i:12;s:4:\"1256\";i:13;s:4:\"1257\";i:14;s:4:\"1259\";i:15;s:4:\"1262\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('194','a:5:{i:0;s:4:\"1107\";i:1;s:4:\"1108\";i:2;s:4:\"1124\";i:3;s:4:\"1159\";i:4;s:4:\"1160\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('196','a:37:{i:0;s:4:\"1004\";i:1;s:4:\"1005\";i:2;s:4:\"1011\";i:3;s:4:\"1018\";i:4;s:4:\"1019\";i:5;s:4:\"1020\";i:6;s:4:\"1021\";i:7;s:4:\"1022\";i:8;s:4:\"1023\";i:9;s:4:\"1024\";i:10;s:4:\"1025\";i:11;s:4:\"1042\";i:12;s:4:\"1044\";i:13;s:4:\"1057\";i:14;s:4:\"1058\";i:15;s:4:\"1059\";i:16;s:4:\"1061\";i:17;s:4:\"1062\";i:18;s:4:\"1063\";i:19;s:4:\"1064\";i:20;s:4:\"1098\";i:21;s:4:\"1133\";i:22;s:4:\"1135\";i:23;s:4:\"1136\";i:24;s:4:\"1137\";i:25;s:4:\"1138\";i:26;s:4:\"1162\";i:27;s:4:\"1163\";i:28;s:4:\"1164\";i:29;s:4:\"1165\";i:30;s:4:\"1197\";i:31;s:4:\"1198\";i:32;s:4:\"1204\";i:33;s:4:\"1205\";i:34;s:4:\"1206\";i:35;s:4:\"1235\";i:36;s:4:\"1236\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('197','a:12:{i:0;s:4:\"1000\";i:1;s:4:\"1112\";i:2;s:4:\"1115\";i:3;s:4:\"1202\";i:4;s:4:\"1203\";i:5;s:4:\"1246\";i:6;s:4:\"1252\";i:7;s:4:\"1255\";i:8;s:4:\"1256\";i:9;s:4:\"1261\";i:10;s:4:\"1262\";i:11;s:4:\"1263\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('198','a:6:{i:0;s:4:\"1000\";i:1;s:4:\"1197\";i:2;s:4:\"1198\";i:3;s:4:\"1204\";i:4;s:4:\"1205\";i:5;s:4:\"1206\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('199','a:39:{i:0;s:4:\"1000\";i:1;s:4:\"1001\";i:2;s:4:\"1002\";i:3;s:4:\"1003\";i:4;s:4:\"1004\";i:5;s:4:\"1005\";i:6;s:4:\"1006\";i:7;s:4:\"1007\";i:8;s:4:\"1008\";i:9;s:4:\"1009\";i:10;s:4:\"1010\";i:11;s:4:\"1011\";i:12;s:4:\"1013\";i:13;s:4:\"1042\";i:14;s:4:\"1044\";i:15;s:4:\"1057\";i:16;s:4:\"1058\";i:17;s:4:\"1059\";i:18;s:4:\"1060\";i:19;s:4:\"1081\";i:20;s:4:\"1091\";i:21;s:4:\"1092\";i:22;s:4:\"1093\";i:23;s:4:\"1109\";i:24;s:4:\"1110\";i:25;s:4:\"1112\";i:26;s:4:\"1115\";i:27;s:4:\"1133\";i:28;s:4:\"1136\";i:29;s:4:\"1137\";i:30;s:4:\"1138\";i:31;s:4:\"1162\";i:32;s:4:\"1163\";i:33;s:4:\"1164\";i:34;s:4:\"1165\";i:35;s:4:\"1238\";i:36;s:4:\"1246\";i:37;s:4:\"1250\";i:38;s:4:\"1251\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('201','a:8:{i:0;s:4:\"1016\";i:1;s:4:\"1017\";i:2;s:4:\"1107\";i:3;s:4:\"1108\";i:4;s:4:\"1124\";i:5;s:4:\"1197\";i:6;s:4:\"1198\";i:7;s:4:\"1203\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('203','a:1:{i:0;s:4:\"1000\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('204','a:21:{i:0;s:4:\"1000\";i:1;s:4:\"1010\";i:2;s:4:\"1012\";i:3;s:4:\"1019\";i:4;s:4:\"1020\";i:5;s:4:\"1021\";i:6;s:4:\"1022\";i:7;s:4:\"1023\";i:8;s:4:\"1024\";i:9;s:4:\"1030\";i:10;s:4:\"1031\";i:11;s:4:\"1032\";i:12;s:4:\"1033\";i:13;s:4:\"1034\";i:14;s:4:\"1035\";i:15;s:4:\"1036\";i:16;s:4:\"1200\";i:17;s:4:\"1201\";i:18;s:4:\"1234\";i:19;s:4:\"1256\";i:20;s:4:\"1257\";}');
INSERT INTO `sessmics` (`sessmicsID`,`sessmicList`) VALUES ('206','a:21:{i:0;s:4:\"1000\";i:1;s:4:\"1010\";i:2;s:4:\"1012\";i:3;s:4:\"1019\";i:4;s:4:\"1020\";i:5;s:4:\"1021\";i:6;s:4:\"1022\";i:7;s:4:\"1023\";i:8;s:4:\"1024\";i:9;s:4:\"1030\";i:10;s:4:\"1031\";i:11;s:4:\"1032\";i:12;s:4:\"1033\";i:13;s:4:\"1034\";i:14;s:4:\"1035\";i:15;s:4:\"1036\";i:16;s:4:\"1200\";i:17;s:4:\"1201\";i:18;s:4:\"1234\";i:19;s:4:\"1256\";i:20;s:4:\"1257\";}');
/*!40000 ALTER TABLE `sessmics` ENABLE KEYS */;


--
-- Create Table `studio`
--

DROP TABLE IF EXISTS `studio`;
CREATE TABLE `studio` (
  `stdID` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `stdName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desk` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`stdID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `studio`
--

/*!40000 ALTER TABLE `studio` DISABLE KEYS */;
INSERT INTO `studio` (`stdID`,`stdName`,`desk`) VALUES ('1','Studio One','Neve 88R');
INSERT INTO `studio` (`stdID`,`stdName`,`desk`) VALUES ('2','Studio Two','Euphonix System 5');
INSERT INTO `studio` (`stdID`,`stdName`,`desk`) VALUES ('3','Studio Three','Neve VXS');
/*!40000 ALTER TABLE `studio` ENABLE KEYS */;


--
-- Create Table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `usrID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `salt` char(16) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `usrGroup` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`usrID`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('1','dan','53074ee27aef3fe3a9dcbab3964bde6a445301199b07901985e497c4a5eeeb2a','2f862a8859ff005','purdz0@gmail.com','admin');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('2','Jez','dacb8062525329ea961f0be177154a486ed2b35d9bdc1ec9e2e1ba744b772480','55b47b9734284692','chaikidd_music@yahoo.com','studio');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('4','alex','43c74e1ae2fa5821f2681007a3c94a813281cce72058f4c8f91cf269a5b05301','3fa096362b14daef','alexwatson1@mac.com','admin');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('5','Chris','5f7b03cbd9a3970301bc310e598e8cb7f6a40108a7af08edd3201e2a30c01f3d','c594d311fc18da2','chris.james.parker@me.com','studio');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('6','Joshua','5d88aabf6c7cd8cd5cc3e281c3d8fe3c3295878cdb05ca5a871efa9389668a81','5044e3646d17222e','joshuaulicthomas@gmail.com','studio');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('7','Mat','3a9c9b960f9171e46c905f76056883b63d0d40d05a1438a3cbdbe9729fb39cee','1a60022c2ef39b2c','mat.angel@me.com','studio');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('8','reception','ea4c4450a98b67c4cb8c0ed59a840ed1d9c4d3c723f68135150cee273edfdf8c','62c6b809472cb5e9','workshop@angelstudios.co.uk','studio');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('9','Joe','4fede92e2ce4a75b6d461ae2dfc67038e8ab5596410192571daa33bc4a84af50','234a4748121896c','U1053818@unimail.hud.ac.uk','studio');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('10','steamo','f69dfc15345ef9f8fcf4a806f1cf79d659f9f3d0f0c05ebe5d692735e3085edc','31fccc496659e012','steveprice1@mac.com','studio');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('11','Gary','f434274d2fb0c08416eaeafc6dcf2e8bae6488bbbbb4f9221081a0ce2646be6e','6185cb3f79825810','june654@gmail.com','studio');
INSERT INTO `users` (`usrID`,`username`,`password`,`salt`,`email`,`usrGroup`) VALUES ('12','test','f0c070f1da164204e37767ba7bd5d8c7f06293320f02cd1f2e3428fdb1d7db42','4849b0d510809980','test@test.com','studio');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

